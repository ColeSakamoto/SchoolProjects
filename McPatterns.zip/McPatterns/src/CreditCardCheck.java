
public class CreditCardCheck
{
  private String cardNum;
  private double fee;
  private boolean isSuccessful;
  private String cardName;
  String regex = "[0-9]+";
  
  //CreditCard number cannot be empty
  public CreditCardCheck(String card, String total)
  {
    this.cardNum = card.trim();
  
    if (total != null) {
      try
      {
        this.fee = Double.parseDouble(total.replaceAll("\\s+", ""));
      }
      catch (NumberFormatException e)
      {
        System.out.println("NumberFormatException");
      }
    }
  }

  public void getCardType()
  {
    if (this.cardNum.length() == 0)
    {
      System.out.println("Card number is empty");
    }
    else if (this.cardNum.length() > 19)
    {
      System.out.println("Card number is above 19 digits");
    }
    else if (!this.cardNum.matches(this.regex))
    {
      System.out.println("Invalid input detected");
    }
    else if (this.fee == 0.0) {
    	System.out.println("No item was ordered");
    }
    //MasterCard
    //Ex.5357365836458674
    else if ((this.cardNum.charAt(0) == '5') && (this.cardNum.length() == 16))
    {
      if ((this.cardNum.charAt(1) == '1') || (this.cardNum.charAt(1) == '2') || (this.cardNum.charAt(1) == '3') || (this.cardNum.charAt(1) == '4') || 
        (this.cardNum.charAt(1) == '5'))
      {
        MasterCC aMaster = new MasterCC(this.cardNum);
        aMaster.chargeCard(this.fee);
        this.cardName = aMaster.getName();
        
        System.out.println("Total: $" + aMaster.getFees()); // Verify that the card was charged by asking what the fee was
        this.isSuccessful = true;
      }
    }
    //Visa
    //Ex. 4756485769785
    //Ex. 4264456801723645
    else if (this.cardNum.charAt(0) == '4')
    {
      if ((this.cardNum.length() == 16) || (this.cardNum.length() == 13))
      {
        VisaCC aVisa = new VisaCC(this.cardNum);
        aVisa.chargeCard(this.fee);
        this.cardName = aVisa.getName();
        
        System.out.println("Total: $" + aVisa.getFees());
        this.isSuccessful = true;
      }
    }
    //AmericanExpress
    //Ex. 342645768792374
    else if ((this.cardNum.charAt(0) == '3') && (this.cardNum.length() == 15))
    {
      if ((this.cardNum.charAt(1) == '4') || (this.cardNum.charAt(1) == '7'))
      {
        AmExCC aAmExpress = new AmExCC(this.cardNum);
        aAmExpress.chargeCard(this.fee);
        this.cardName = aAmExpress.getName();
        
        System.out.println("Total: $" + aAmExpress.getFees());
        this.isSuccessful = true;
      }
    }
    //Discover
    //Ex. 6011364575564756
    else if ((this.cardNum.charAt(0) == '6') && (this.cardNum.charAt(1) == '0') && (this.cardNum.charAt(2) == '1') && (this.cardNum.charAt(3) == '1') && (this.cardNum.length() == 16))
    {
      Discover aDiscover = new Discover(this.cardNum);
      aDiscover.chargeCard(this.fee);
      this.cardName = aDiscover.getName();
      
      System.out.println("Total: $" + aDiscover.getFees());
      this.isSuccessful = true;
    }
    else
    {
      System.out.println("Card number does not match any existing card types");
    }
  }
  
  // Was the charge successful?
  public boolean isSuccessful()
  {
    return this.isSuccessful;
  }
  
  public void setCardType(String name)
  {
    this.cardName = name;
  }
  
  public String getCardName()
  {
    return this.cardName;
  }
  
  public void resetFee()
  {
    this.fee = 0.0D;
  }
}


