import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

class McPatternsGUI
  extends JFrame
{
  McPatternsPresenter presenter;
  CreditCardCheck newCard;
  currentOrderGUI currentO = new currentOrderGUI();
  
  public McPatternsGUI(McPatternsPresenter presenter)
  {
    this.presenter = presenter;
    presenter.attachView(this);
    showGUI();
    this.currentO.newOrder();
  }
  
  private void showGUI()
  {
    this.presenter.loadMenuItems();
    
    JFrame theFrame = new JFrame("Menu");
    theFrame.setDefaultCloseOperation(3);
    theFrame.setLayout(new BorderLayout());
    
    JPanel title = new JPanel(new FlowLayout());
    
    JLabel menu = new JLabel("Item Menu");
    menu.setFont(new Font("Serif", 1, 18));
    
    title.add(menu);
    
    title.setBackground(new Color(253, 255, 225));
    
    JPanel orderPane = new JPanel();
    orderPane.setBackground(new Color(222, 222, 221));
    
    orderPane.setLayout(new BoxLayout(orderPane, 3));
    final JLabel orderDetails = new JLabel("Add CC # below");
    orderDetails.setFont(new Font("Courier", 0, 15));
    
    orderPane.setBorder(BorderFactory.createRaisedBevelBorder());
    orderPane.add(orderDetails);
    final JTextField ccEntry = new JTextField("");
    
    JButton confirm = new JButton("Place Order");
    ccEntry.setPreferredSize(new Dimension(200, 30));
    ccEntry.setMaximumSize(new Dimension(500, 30));
    confirm.setBackground(new Color(205,206,249));
    confirm.setOpaque(true);
    
    this.newCard = new CreditCardCheck(ccEntry.getText(), this.currentO.getTotal());
    this.currentO.addItem("Customer Receipt Copy");
    this.currentO.addItem("");
    
    //Action for placing a order
    confirm.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        McPatternsGUI.this.newCard = new CreditCardCheck(ccEntry.getText(), McPatternsGUI.this.currentO.getTotal());
        McPatternsGUI.this.newCard.getCardType();
        if ((McPatternsGUI.this.newCard.isSuccessful()) && (McPatternsGUI.this.currentO.getTotal() != "0.0"))
        {
          orderDetails.setText("Order confirmed for: " + ccEntry.getText());
          
          McPatternsGUI.this.currentO.addItem("Order processed: " + McPatternsGUI.this.newCard.getCardName() + " " + "****" + ccEntry.getText().substring(ccEntry.getText().length() - 4, ccEntry.getText().length()));
          McPatternsGUI.this.currentO.addItem("");
          McPatternsGUI.this.currentO.addItem("Have A Nice Day");
          McPatternsGUI.this.currentO.addItem("-----------------------");
          
          System.out.println("Order processed: " + McPatternsGUI.this.newCard.getCardName() + " " + "****" + ccEntry.getText().substring(ccEntry.getText().length() - 4, ccEntry.getText().length()));
          System.out.println("-----------------------");
          McPatternsGUI.this.currentO.startNewOrder();
          McPatternsGUI.this.currentO.addItem("Customer Receipt Copy");
          McPatternsGUI.this.currentO.addItem("");
        }
        else
        {
          orderDetails.setText("Invalid transaction: " + ccEntry.getText());
        }
      }
    });
    JButton cancel = new JButton("Cancel");
    cancel.setBackground(new Color(249,205,205));
    cancel.setOpaque(true);
    //Action for canceling a order
    cancel.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        McPatternsGUI.this.currentO.startNewOrder();
        McPatternsGUI.this.currentO.addItem("-----------------------");
        McPatternsGUI.this.currentO.addItem("Customer Receipt Copy");
        McPatternsGUI.this.currentO.addItem("");
        orderDetails.setText("Order cancelled");
        McPatternsGUI.this.newCard.resetFee();
        System.out.println("-----------------------");
        System.out.println();
      }
    });
    JButton clear = new JButton("Clear Orders");
    clear.setBackground(new Color(249,228,205));
    clear.setOpaque(true);
    clear.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        McPatternsGUI.this.currentO.resetOrder();
        McPatternsGUI.this.currentO.addItem("Customer Receipt Copy");
        McPatternsGUI.this.currentO.addItem("");
        orderDetails.setText("Orders cleared");
        McPatternsGUI.this.newCard.resetFee();
        System.out.println("-----------------------");
        System.out.println();
      }
    });
    orderPane.add(ccEntry);
    orderPane.add(confirm);
    orderPane.add(cancel);
    orderPane.add(clear);
    
    JPanel buttonPanel = new JPanel();
    buttonPanel.setBackground(new Color(253, 255, 225));
    buttonPanel.setLayout(new FlowLayout());
    
    final McPatternsPresenter presenter = new McPatternsPresenter();
    presenter.loadMenuItems();
    int itemsSize = presenter.items.size();
    //Action for menu buttons
    ActionListener menuListener = new ActionListener()
    {
      Double cost;
      
      public void actionPerformed(ActionEvent actionEvent)
      {
        for (int i = 0; i < presenter.getItems().size(); i++) {
          if (actionEvent.getActionCommand() == presenter.items.get(i))
          {
            this.cost = Double.valueOf(Double.parseDouble((String)presenter.prices.get(i)));
            
            McPatternsGUI.this.currentO.addToTotal(this.cost.doubleValue());
          }
        }
        McPatternsGUI.this.currentO.addItem(actionEvent.getActionCommand().toString() + " $" + this.cost);
        
        McPatternsGUI.this.currentO.addPrice();
        System.out.println(actionEvent.getActionCommand().toString() + " $" + this.cost);
      }
    };
    for (int i = 0; i < itemsSize; i++)
    {
      JButton buttons = new JButton();
      buttons.setText(((String)presenter.items.get(i)).toString());
      buttons.addActionListener(menuListener);
      buttonPanel.add(buttons);
    }
    theFrame.add(title, "North");
    theFrame.add(buttonPanel, "Center");
    theFrame.add(orderPane, "East");
    theFrame.setSize(800, 600);
    
    theFrame.pack();
    theFrame.setLocationRelativeTo(null);
    theFrame.setVisible(true);
  }
}
