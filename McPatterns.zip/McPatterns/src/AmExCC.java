public class AmExCC extends CreditCard
{
  private double fees;
  private String name = "AmericanExpress";
  
  public AmExCC(String card)
  {
  
  }
  
  public void chargeCard(double fee)
  {
    this.fees += fee;
  }
  
  public double getFees()
  {
    return this.fees;
  }
  
  public String getName()
  {
    return this.name;
  }
}
