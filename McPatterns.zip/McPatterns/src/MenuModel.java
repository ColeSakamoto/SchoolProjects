class MenuModel {
    // Add your implementation for Menu Items here.
    // Determine what data you want to store for each item.
	
}