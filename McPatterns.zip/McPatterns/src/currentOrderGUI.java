import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;

import javax.swing.*;
import javax.swing.text.DefaultCaret;
 
public class currentOrderGUI {
    
   private JFrame mainFrame;
   private JLabel headerLabel;
   //private JLabel statusLabel;
   private JPanel controlPanel;
   final JTextArea commentTextArea = new JTextArea("",20,40);
   
   private String theTotal;
   private double total;
  
   
   
   private static DecimalFormat df2 = new DecimalFormat(".##");
   
   
   public currentOrderGUI(){
	   //Enable auto scroll for receipt panel
	   DefaultCaret caret = (DefaultCaret)commentTextArea.getCaret();
	   caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
   }
 
  public void newOrder() {
	  prepareGUI();
      showTextArea();
      
  }

   private void prepareGUI(){
	   commentTextArea.setEditable(false);
	  commentTextArea.setBackground((new Color (253, 255, 225)));
	  commentTextArea.setFont(new Font("Courier", Font.PLAIN, 15));
	  
	 
      mainFrame = new JFrame("Current Orders");
      mainFrame.setSize(400,400);
      mainFrame.setLayout(new BorderLayout());
      mainFrame.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
            System.exit(0);
         }        
      });    
      headerLabel = new JLabel("", JLabel.CENTER);        
     // statusLabel = new JLabel("",JLabel.CENTER);    

     // statusLabel.setSize(350,100);

      controlPanel = new JPanel();
      controlPanel.setLayout(new FlowLayout());
      
  
      mainFrame.add(headerLabel);
      mainFrame.add(controlPanel);
     // mainFrame.add(statusLabel);
      mainFrame.setVisible(true);  

   }

   private void showTextArea(){
      headerLabel.setText("Place the order once finished"); 

    //  JLabel  commentlabel= new JLabel("Comments: ", JLabel.RIGHT);

   

      
      
      JScrollPane scrollPane = new JScrollPane(commentTextArea);    
    
      
//      JButton showButton = new JButton("Show");
//
//      showButton.addActionListener(new ActionListener() {
//         public void actionPerformed(ActionEvent e) {     
//            statusLabel.setText( commentTextArea.getText());        
//         }
//      }); 

    //  controlPanel.add(commentlabel);
      controlPanel.add(scrollPane);        
//      controlPanel.add(showButton);
      mainFrame.setVisible(true);  
   }
   
   //add item to order
   public void addItem(String item) {
	   commentTextArea.append(item+"\n");
	   //commentTextArea.update(commentTextArea.getGraphics());
   }
 
   
   public void addPrice() {
	   commentTextArea.append("Total: "+"$"+theTotal+"\n");
	   commentTextArea.append("\n");
	   //commentTextArea.update(commentTextArea.getGraphics());
   }  
   
  
   
   public void addToTotal(double cost) {
	 total += cost;
	 theTotal = df2.format(total);
     } 
   
   /**
 * cancels order and clears order UI
 */
public void resetOrder() {
	   commentTextArea.setText(null);
	   theTotal = "0.0";
	   total = 0.0;
   }


/**
* ends previous order
*/
   public void startNewOrder() {
	   
	   theTotal = "0.0";
	   total = 0.0;
	   
   }
   
   
   
   public String getTotal() {
	   return theTotal;
   }

  }
   
   
