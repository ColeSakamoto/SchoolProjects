public class VisaCC extends CreditCard
{
  private double fees;
  private String name = "Visa";
  
  public VisaCC(String card)
  {
    
  }
  
  public void chargeCard(double fee)
  {
    this.fees += fee;
  }
  
  public double getFees()
  {
    return this.fees;
  }
  
  public String getName()
  {
    return this.name;
  }
}
