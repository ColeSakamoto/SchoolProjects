public class Discover extends CreditCard
{
  private double fees;
  private String name = "Discover";
  
  public Discover(String card)
  {
   
  }
  
  public void chargeCard(double fee)
  {
    this.fees += fee;
  }
  
  public double getFees()
  {
    return this.fees;
  }
  
  public String getName()
  {
    return this.name;
  }
}
