public class McPatterns {
    public static void main(String[] args){
        McPatternsGUI gui = new McPatternsGUI(new McPatternsPresenter());
       
       
    }
 }