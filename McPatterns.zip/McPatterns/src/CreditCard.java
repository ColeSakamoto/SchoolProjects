
public abstract class CreditCard {
	  private double fees;
	  private String name;
		
	  public void chargeCard() {
	}	  
	  
	  public double getFees() {
		  return fees;
	  }
	
	  public String getName() {
		  return name;
	  }
	 
}
