import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

class McPatternsPresenter {
    //This is the class reads menu.txt and is used in McPatternsGUI
   
    McPatternsGUI view;
    ArrayList<String> items = new ArrayList<String>();
	ArrayList<String> prices = new ArrayList<String>();
	
	
    void loadMenuItems() {
        // TODO: Add code to read a file and load the menu items.
    	
		 // The name of the file to open.
        String fileName = "menu";
        String line = null;

        try {
        	FileInputStream stream = new FileInputStream("menu.txt");
        	InputStreamReader isr = new InputStreamReader(stream);
        	BufferedReader br = new BufferedReader(isr);
         
          while((line = br.readLine()) != null) {        	             
               String output = line.substring(0, line.indexOf('|'));
              items.add(output);
              String output1 = line.substring(line.indexOf('|')+1, line.length());
              prices.add(output1);
         } 
            br.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
        }
    }

    void attachView(McPatternsGUI view) {
        this.view = view;
    }

    public ArrayList<String> getItems() {
    	return items;
    }
    
    public ArrayList<String> getPrices() {
    	return prices;
    }
}