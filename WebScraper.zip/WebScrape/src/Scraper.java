

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scraper {
////DATABASE CONFIGURATIONS FOR MYSQL
	public static final String URL1 = "jdbc:mysql://localhost:3306/WebItems?autoReconnect=true&useSSL=false";
	public static final String USER = "root";
	public static final String PASSWORD = "902772404";  
	
	Connection conn1 = null;  
	ResultSet rs;
	Statement stmt = null;
	
	String sql = "";
	
	WebDriver driver = new ChromeDriver();
	
	public void search(String link) {
			driver.get(link);
			WebElement element = driver.findElement(By.className("a-box-group"));
			
			String price = element.getText();
			price = price.substring(price.indexOf("$"),price.indexOf(".")+3);
			
			
			element = driver.findElement(By.id("title_feature_div"));
			String title = element.getText();
			
			System.out.println(price);
			System.out.println(title);
			
			updateTxt(title, price);
			
			driver.quit();
	}
	
	public void updateTxt(String title, String price) {
		String result = "";
		Double pr;
		double diff;
		price = price.replace(",", "");
	    double InPrice = Double.parseDouble(price.substring(price.indexOf("$")+1, price.length()));
		try {
		     conn1 = DriverManager.getConnection(URL1, USER, PASSWORD);
		     stmt = conn1.createStatement();	
		     
		     sql = "SELECT Title, Price FROM Items WHERE Title = '"+title+"'";
	    	 rs = stmt.executeQuery(sql);
	    	 
	    	 if (rs.next()){
	    		 result = rs.getString("Title");
		    	
		    	 System.out.println(result);
	    	 }
		     if (title.equals(result)) { //dont change if price is the same
		    		 
		    		 pr = rs.getDouble("Price"); 
		    		 if (pr != InPrice) {
		    		 diff = pr-InPrice;
		    		 sql = "UPDATE ITEMS SET Price = "+InPrice+", PriceChange = "+diff+"WHERE Title = '"+title+"'";
		    		 stmt.executeUpdate(sql);
		    		 }
		    	
		    	 }
		     else {
		    	 sql = "INSERT INTO Items (Title, Price) VALUES('"+title+"',"+InPrice+")";
		    	 stmt.executeUpdate(sql);
		     }
		    	 
		     }
		 catch (Exception a) {
	    		
				a.printStackTrace();
			}
		
	}
	
	
	
	public static void main (String[] args) {
		
		
		Scraper sc = new Scraper();
		
		sc.search("https://www.amazon.com/Wireless-Powered-Music-System-Black/dp/B01M9CIX3M/ref=sr_1_5?s=electronics&ie=UTF8&qid=1549480210&sr=1-5&keywords=kef");
		//sc.updateTxt("LS50 Wireless Powered Music System (Black, Pair)", "$12.00");
	}
}
