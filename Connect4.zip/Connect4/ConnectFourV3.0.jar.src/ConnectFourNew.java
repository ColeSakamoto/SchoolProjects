/*     */ import java.io.PrintStream;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ public class ConnectFourNew
/*     */ {
/*     */   JFrame frame;
/*     */   JPanel panel;
/*  11 */   final int rowTiles = BOARDSIZE;
/*  12 */   final int colTiles = BOARDSIZE;
/*  13 */   static int[][] grid = new int[1][1];
/*  14 */   int row; int col; int rowSelected; int colSelected = 0;
/*  15 */   int pTurn = 0;
/*  16 */   boolean win = false;
/*  17 */   JButton[][] button = new JButton[this.rowTiles][this.colTiles];
/*     */   JButton clear;
/*     */   javax.swing.JLabel whoWon;
/*  20 */   java.awt.GridLayout myGrid = new java.awt.GridLayout(BOARDSIZE, BOARDSIZE);
/*     */   
/*  22 */   ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*  23 */   java.net.URL resource = this.classLoader.getResource("images/BlackDot.jpg");
/*  24 */   java.net.URL resource1 = this.classLoader.getResource("images/REDload.gif");
/*  25 */   java.net.URL resource2 = this.classLoader.getResource("images/BLUEload.gif");
/*  26 */   java.net.URL resource3 = this.classLoader.getResource("images/BLUEWin.png");
/*  27 */   java.net.URL resource4 = this.classLoader.getResource("images/REDWin.png");
/*  28 */   java.net.URL resource5 = this.classLoader.getResource("images/Preloader.gif");
/*  29 */   final ImageIcon blnk = new ImageIcon(this.resource);
/*  30 */   final ImageIcon p1 = new ImageIcon(this.resource1);
/*  31 */   final ImageIcon p2 = new ImageIcon(this.resource2);
/*  32 */   final ImageIcon bWin = new ImageIcon(this.resource3);
/*  33 */   final ImageIcon rWin = new ImageIcon(this.resource4);
/*  34 */   final ImageIcon status = new ImageIcon(this.resource5);
/*     */   static int BOARDSIZE;
/*     */   static int CONTOWIN;
/*     */   JButton gameStatus;
/*     */   
/*     */   public ConnectFourNew()
/*     */   {
/*  41 */     this.frame = new JFrame("Welcome to Connect Four");
/*  42 */     this.frame.setDefaultCloseOperation(3);
/*  43 */     this.panel = new JPanel();
/*  44 */     this.panel.setLayout(this.myGrid);
/*     */     
/*     */ 
/*  47 */     this.gameStatus = new JButton("");
/*     */     
/*  49 */     this.clear = new JButton("Clear");
/*  50 */     this.clear.addActionListener(new ConnectFourNew.clearListener());
/*  51 */     this.clear.setPreferredSize(new java.awt.Dimension(50, 50));
/*  52 */     this.panel.setPreferredSize(new java.awt.Dimension(700, 700));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */     int offset = 3;
/*  62 */     int offsetCol = 1;
/*  63 */     for (int x = BOARDSIZE - offset; x >= 0; x--) {
/*  64 */       for (int y = BOARDSIZE - offsetCol; y >= 0; y--) {
/*  65 */         grid[x][y] = -1;
/*  66 */         System.out.println("Setting up restricted spot at " + x + " " + y);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  72 */     for (this.row = 0; this.row < BOARDSIZE - 1; this.row += 1) {
/*  73 */       for (this.col = 0; this.col < BOARDSIZE - 1; this.col += 1) {
/*  74 */         System.out.println("Setting up button at " + this.row + " " + this.col);
/*  75 */         this.button[this.row][this.col] = new JButton(this.blnk);
/*  76 */         this.button[this.row][this.col].addActionListener(new ConnectFourNew.buttonListener());
/*  77 */         this.panel.add(this.button[this.row][this.col]);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  84 */     this.frame.setContentPane(this.panel);
/*  85 */     this.frame.pack();
/*  86 */     this.frame.setVisible(true);
/*     */     
/*     */ 
/*     */ 
/*  90 */     this.panel.add(this.gameStatus);
/*  91 */     this.gameStatus.setIcon(this.status);
/*     */     
/*  93 */     this.panel.add(this.clear);
/*     */   }
/*     */   
/*     */   class buttonListener implements java.awt.event.ActionListener { buttonListener() {}
/*     */     
/*  98 */     public void actionPerformed(java.awt.event.ActionEvent event) { for (ConnectFourNew.this.row = (ConnectFourNew.BOARDSIZE - 2); ConnectFourNew.this.row >= 0; ConnectFourNew.this.row -= 1) {
/*  99 */         for (ConnectFourNew.this.col = (ConnectFourNew.BOARDSIZE - 1); ConnectFourNew.this.col >= 0; ConnectFourNew.this.col -= 1)
/* 100 */           if (ConnectFourNew.this.button[ConnectFourNew.this.row][ConnectFourNew.this.col] == event.getSource()) {
/* 101 */             if ((ConnectFourNew.this.pTurn % 2 == 0) && (ConnectFourNew.grid[ConnectFourNew.this.row][ConnectFourNew.this.col] == 0)) {
/* 102 */               ConnectFourNew.this.button[ConnectFourNew.this.row][ConnectFourNew.this.col].setIcon(ConnectFourNew.this.p1);
/* 103 */               ConnectFourNew.grid[ConnectFourNew.this.row][ConnectFourNew.this.col] = 1;
/* 104 */               System.out.println("Selected Row: " + ConnectFourNew.this.row + " Col: " + ConnectFourNew.this.col);
/*     */               try {
/* 106 */                 ConnectFourNew.grid[(ConnectFourNew.this.row - 1)][ConnectFourNew.this.col] = 0;
/*     */               } catch (ArrayIndexOutOfBoundsException e) {
/* 108 */                 System.out.println("Maxed height reached");
/*     */               }
/* 110 */               if (ConnectFourNew.this.checkWin()) {
/* 111 */                 System.out.println("Red win");
/* 112 */                 ConnectFourNew.this.gameStatus.setIcon(ConnectFourNew.this.rWin);
/* 113 */                 for (int x = ConnectFourNew.BOARDSIZE - 1; x >= 0; x--) {
/* 114 */                   for (int y = ConnectFourNew.BOARDSIZE - 1; y >= 0; y--) {
/* 115 */                     ConnectFourNew.grid[x][y] = -1;
/*     */                   }
/*     */                 }
/*     */               }
/* 119 */               ConnectFourNew.this.pTurn += 1;
/* 120 */               break;
/*     */             }
/* 122 */             if ((ConnectFourNew.this.pTurn % 2 == 1) && (ConnectFourNew.grid[ConnectFourNew.this.row][ConnectFourNew.this.col] == 0)) {
/* 123 */               ConnectFourNew.this.button[ConnectFourNew.this.row][ConnectFourNew.this.col].setIcon(ConnectFourNew.this.p2);
/* 124 */               ConnectFourNew.grid[ConnectFourNew.this.row][ConnectFourNew.this.col] = 2;
/* 125 */               System.out.println("Selected Row: " + ConnectFourNew.this.row + " Col: " + ConnectFourNew.this.col);
/*     */               try {
/* 127 */                 ConnectFourNew.grid[(ConnectFourNew.this.row - 1)][ConnectFourNew.this.col] = 0;
/*     */               } catch (ArrayIndexOutOfBoundsException e) {
/* 129 */                 System.out.println("Maxed height reached");
/*     */               }
/* 131 */               if (ConnectFourNew.this.checkWin()) {
/* 132 */                 System.out.println("Blue win");
/* 133 */                 ConnectFourNew.this.gameStatus.setIcon(ConnectFourNew.this.bWin);
/* 134 */                 for (int x = ConnectFourNew.BOARDSIZE - 1; x >= 0; x--) {
/* 135 */                   for (int y = ConnectFourNew.BOARDSIZE - 1; y >= 0; y--) {
/* 136 */                     ConnectFourNew.grid[x][y] = -1;
/*     */                   }
/*     */                 }
/*     */               }
/* 140 */               ConnectFourNew.this.pTurn += 1;
/* 141 */               break;
/*     */             }
/* 143 */             System.out.println("");
/* 144 */             System.out.println("Selected Row: " + ConnectFourNew.this.row + " Col: " + ConnectFourNew.this.col);
/* 145 */             System.out.println("Game is still running");
/* 146 */             System.out.println("Click a different spot or start a new game");
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   class clearListener implements java.awt.event.ActionListener {
/*     */     clearListener() {}
/*     */     
/*     */     public void actionPerformed(java.awt.event.ActionEvent event) {
/* 156 */       for (int x = ConnectFourNew.BOARDSIZE - 2; x >= 0; x--) {
/* 157 */         for (int y = ConnectFourNew.BOARDSIZE - 2; y >= 0; y--) {
/* 158 */           System.out.println("Clearing spot: x " + x + " y " + y);
/* 159 */           ConnectFourNew.grid[x][y] = -1;
/* 160 */           ConnectFourNew.this.button[x][y].setIcon(ConnectFourNew.this.blnk);
/*     */         }
/*     */       }
/*     */       
/* 164 */       for (int y = ConnectFourNew.this.colTiles - 1; y >= 0; y--) {
/* 165 */         ConnectFourNew.grid[(ConnectFourNew.BOARDSIZE - 2)][y] = 0;
/*     */       }
/*     */       
/* 168 */       ConnectFourNew.this.win = false;
/* 169 */       ConnectFourNew.this.gameStatus.setIcon(ConnectFourNew.this.status);
/*     */       
/* 171 */       System.out.println("Done");
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean checkWin()
/*     */   {
/* 177 */     int matchsFound = 1;
/*     */     
/* 179 */     System.out.println("Horizontal check: ");
/* 180 */     for (int x = 0; x < BOARDSIZE; x++) {
/* 181 */       for (int y = 0; y < BOARDSIZE - CONTOWIN + 1; y++)
/*     */       {
/* 183 */         if ((grid[x][y] != 0) && (grid[x][y] != -1)) {
/* 184 */           for (int c = 1; c < CONTOWIN; c++) {
/* 185 */             if (grid[x][y] == grid[x][(y + c)]) {
/* 186 */               matchsFound++;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 191 */         if (matchsFound >= CONTOWIN) {
/* 192 */           this.win = true;
/*     */         }
/*     */         
/* 195 */         matchsFound = 1;
/*     */       }
/*     */     }
/*     */     
/* 199 */     System.out.println("Vertical check: ");
/* 200 */     for (int x = 0; x < BOARDSIZE - CONTOWIN; x++) {
/* 201 */       for (int y = 0; y < BOARDSIZE; y++)
/*     */       {
/* 203 */         if ((grid[x][y] != 0) && (grid[x][y] != -1)) {
/* 204 */           for (int c = 1; c < CONTOWIN; c++) {
/* 205 */             if (grid[x][y] == grid[(x + c)][y]) {
/* 206 */               matchsFound++;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 211 */         if (matchsFound >= CONTOWIN) {
/* 212 */           this.win = true;
/*     */         }
/*     */         
/* 215 */         matchsFound = 1;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 220 */     System.out.println("Diagonal positive check: ");
/* 221 */     for (int x = 0; x < BOARDSIZE - CONTOWIN; x++) {
/* 222 */       for (int y = 0; y < BOARDSIZE - CONTOWIN; y++) {
/* 223 */         if ((grid[x][y] != 0) && (grid[x][y] != -1)) {
/* 224 */           for (int c = 1; c < CONTOWIN; c++) {
/* 225 */             if (grid[x][y] == grid[(x + c)][(y + c)]) {
/* 226 */               matchsFound++;
/*     */             }
/*     */           }
/*     */         }
/* 230 */         if (matchsFound >= CONTOWIN) {
/* 231 */           this.win = true;
/*     */         }
/*     */         
/* 234 */         matchsFound = 1;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 240 */     if (this.col != 0)
/*     */     {
/* 242 */       System.out.println("Diagonal negative check: ");
/* 243 */       for (int x = BOARDSIZE - CONTOWIN; x < BOARDSIZE; x++) {
/* 244 */         for (int y = 0; y < BOARDSIZE - CONTOWIN; y++) {
/* 245 */           if ((grid[x][y] != 0) && (grid[x][y] != -1)) {
/* 246 */             for (int c = 1; c < CONTOWIN; c++) {
/* 247 */               if (grid[x][y] == grid[(x - c)][(y + c)]) {
/* 248 */                 matchsFound++;
/*     */               }
/*     */             }
/*     */           }
/* 252 */           if (matchsFound >= CONTOWIN) {
/* 253 */             this.win = true;
/* 254 */             matchsFound = 0;
/*     */           }
/* 256 */           matchsFound = 1;
/*     */         }
/*     */       }
/*     */     }
/* 260 */     return this.win;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 267 */     if (args.length == 0) {
/* 268 */       System.out.println("<>---------------------MISSING ARGUMENTS-----------------------<>");
/* 269 */       System.out.println("No arguments");
/* 270 */       System.out.println("<>---------------------------------------------------------<>");
/*     */     } else {
/* 272 */       System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");
/*     */       try {
/* 274 */         int boardSize = Integer.parseInt(args[0]);
/* 275 */         int conToWin = Integer.parseInt(args[1]);
/*     */         
/*     */ 
/* 278 */         if (boardSize <= conToWin) {
/* 279 */           System.out.println("<>---------------------INVALID INPUT-----------------------<>");
/* 280 */           System.out.println("Game is not winnable!!!");
/*     */           
/*     */ 
/* 283 */           System.out.println("Ex. BoardSize = 8, ConnectionToWin = 6, is OK");
/*     */           
/* 285 */           System.out.println("Ex. BoardSize = 8, ConnectionToWin = 9, is INVALID");
/* 286 */           System.out.println("<>---------------------------------------------------------<>");
/* 287 */           return;
/*     */         }
/*     */         
/* 290 */         System.out.println("<>---------------------------Welcome To Connect 4 v3.0------------------------------<>");
/* 291 */         System.out.println("boardSize: " + boardSize);
/* 292 */         System.out.println("ConnectionsNeededToWin: " + conToWin);
/* 293 */         BOARDSIZE = boardSize + 2;
/* 294 */         CONTOWIN = conToWin;
/* 295 */         grid = new int[BOARDSIZE][BOARDSIZE];
/* 296 */         javax.swing.SwingUtilities.invokeLater(new Runnable() {
/*     */           public void run() {
/* 298 */             JFrame.setDefaultLookAndFeelDecorated(true);
/* 299 */             new ConnectFourNew();
/*     */           }
/*     */         });
/*     */       }
/*     */       catch (ArrayIndexOutOfBoundsException exception) {
/* 304 */         System.out.println("<>---------------------MISSING ARGUMENTS-----------------------<>");
/* 305 */         System.out.println("Stop trying to crash my program...");
/* 306 */         System.out.println("");
/* 307 */         System.out.println("java -jar Connect4.jar 6 4 is OK");
/* 308 */         System.out.println("java -jar Connect4.jar 6   is INVALID");
/* 309 */         System.out.println("java -jar Connect4.jar     is INVALID");
/* 310 */         System.out.println("<>---------------------------------------------------------<>");
/*     */       }
/*     */       catch (NumberFormatException e) {
/* 313 */         System.out.println("<>---------------------INVALID INPUT-----------------------<>");
/* 314 */         System.out.println("Stop trying to crash my program...");
/* 315 */         System.out.println("Arguments must be a integer");
/* 316 */         System.out.println("java -jar Connect4.jar 6 4 is OK");
/* 317 */         System.out.println("java -jar Connect4.jar 6 e  is INVALID");
/* 318 */         System.out.println("<>---------------------------------------------------------<>");
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/ColeSakamoto/Desktop/ConnectFourV3.0.jar!/ConnectFourNew.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */