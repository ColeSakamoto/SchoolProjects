/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.JButton;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConnectFourNew$buttonListener
/*     */   implements ActionListener
/*     */ {
/*     */   ConnectFourNew$buttonListener(ConnectFourNew paramConnectFourNew) {}
/*     */   
/*     */   public void actionPerformed(ActionEvent event)
/*     */   {
/*  98 */     for (this.this$0.row = (ConnectFourNew.BOARDSIZE - 2); this.this$0.row >= 0; this.this$0.row -= 1) {
/*  99 */       for (this.this$0.col = (ConnectFourNew.BOARDSIZE - 1); this.this$0.col >= 0; this.this$0.col -= 1) {
/* 100 */         if (this.this$0.button[this.this$0.row][this.this$0.col] == event.getSource()) {
/* 101 */           if ((this.this$0.pTurn % 2 == 0) && (ConnectFourNew.grid[this.this$0.row][this.this$0.col] == 0)) {
/* 102 */             this.this$0.button[this.this$0.row][this.this$0.col].setIcon(this.this$0.p1);
/* 103 */             ConnectFourNew.grid[this.this$0.row][this.this$0.col] = 1;
/* 104 */             System.out.println("Selected Row: " + this.this$0.row + " Col: " + this.this$0.col);
/*     */             try {
/* 106 */               ConnectFourNew.grid[(this.this$0.row - 1)][this.this$0.col] = 0;
/*     */             } catch (ArrayIndexOutOfBoundsException e) {
/* 108 */               System.out.println("Maxed height reached");
/*     */             }
/* 110 */             if (this.this$0.checkWin()) {
/* 111 */               System.out.println("Red win");
/* 112 */               this.this$0.gameStatus.setIcon(this.this$0.rWin);
/* 113 */               for (int x = ConnectFourNew.BOARDSIZE - 1; x >= 0; x--) {
/* 114 */                 for (int y = ConnectFourNew.BOARDSIZE - 1; y >= 0; y--) {
/* 115 */                   ConnectFourNew.grid[x][y] = -1;
/*     */                 }
/*     */               }
/*     */             }
/* 119 */             this.this$0.pTurn += 1;
/* 120 */             break;
/*     */           }
/* 122 */           if ((this.this$0.pTurn % 2 == 1) && (ConnectFourNew.grid[this.this$0.row][this.this$0.col] == 0)) {
/* 123 */             this.this$0.button[this.this$0.row][this.this$0.col].setIcon(this.this$0.p2);
/* 124 */             ConnectFourNew.grid[this.this$0.row][this.this$0.col] = 2;
/* 125 */             System.out.println("Selected Row: " + this.this$0.row + " Col: " + this.this$0.col);
/*     */             try {
/* 127 */               ConnectFourNew.grid[(this.this$0.row - 1)][this.this$0.col] = 0;
/*     */             } catch (ArrayIndexOutOfBoundsException e) {
/* 129 */               System.out.println("Maxed height reached");
/*     */             }
/* 131 */             if (this.this$0.checkWin()) {
/* 132 */               System.out.println("Blue win");
/* 133 */               this.this$0.gameStatus.setIcon(this.this$0.bWin);
/* 134 */               for (int x = ConnectFourNew.BOARDSIZE - 1; x >= 0; x--) {
/* 135 */                 for (int y = ConnectFourNew.BOARDSIZE - 1; y >= 0; y--) {
/* 136 */                   ConnectFourNew.grid[x][y] = -1;
/*     */                 }
/*     */               }
/*     */             }
/* 140 */             this.this$0.pTurn += 1;
/* 141 */             break;
/*     */           }
/* 143 */           System.out.println("");
/* 144 */           System.out.println("Selected Row: " + this.this$0.row + " Col: " + this.this$0.col);
/* 145 */           System.out.println("Game is still running");
/* 146 */           System.out.println("Click a different spot or start a new game");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/ColeSakamoto/Desktop/ConnectFourV3.0.jar!/ConnectFourNew$buttonListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */