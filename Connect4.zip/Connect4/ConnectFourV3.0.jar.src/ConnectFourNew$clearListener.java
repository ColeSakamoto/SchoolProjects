/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.JButton;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConnectFourNew$clearListener
/*     */   implements ActionListener
/*     */ {
/*     */   ConnectFourNew$clearListener(ConnectFourNew paramConnectFourNew) {}
/*     */   
/*     */   public void actionPerformed(ActionEvent event)
/*     */   {
/* 156 */     for (int x = ConnectFourNew.BOARDSIZE - 2; x >= 0; x--) {
/* 157 */       for (int y = ConnectFourNew.BOARDSIZE - 2; y >= 0; y--) {
/* 158 */         System.out.println("Clearing spot: x " + x + " y " + y);
/* 159 */         ConnectFourNew.grid[x][y] = -1;
/* 160 */         this.this$0.button[x][y].setIcon(this.this$0.blnk);
/*     */       }
/*     */     }
/*     */     
/* 164 */     for (int y = this.this$0.colTiles - 1; y >= 0; y--) {
/* 165 */       ConnectFourNew.grid[(ConnectFourNew.BOARDSIZE - 2)][y] = 0;
/*     */     }
/*     */     
/* 168 */     this.this$0.win = false;
/* 169 */     this.this$0.gameStatus.setIcon(this.this$0.status);
/*     */     
/* 171 */     System.out.println("Done");
/*     */   }
/*     */ }


/* Location:              /Users/ColeSakamoto/Desktop/ConnectFourV3.0.jar!/ConnectFourNew$clearListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */