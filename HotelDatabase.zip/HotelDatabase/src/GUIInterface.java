import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.text.DefaultCaret;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;
import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;

import java.sql.CallableStatement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class GUIInterface extends JFrame{
	private JFrame mainFrame;
	private JPanel controlPanel;
	 Database database;
	 String query;
	 String sql;
	 java.sql.PreparedStatement pstmt;
	 java.sql.Statement statement;
	 ResultSet rs;
	 int button1 = 0;
	 int button2 = 0;
	 int button3 = 0;
	 int button4 = 0;
	 int button5 = 0;
	 int button6 = 0;    //10
	 int button7 = 0;    //11
	 int button8 = 0;    //Archive
	 int button9 = 0;    //6
	 int button10 = 0;   //7
	 int button11 = 0;   //12
	 int button12 = 0;    //9
	 int button13 = 0;   //16
	 int button14 = 0;   //8
	 int button15 = 0;   //13
	 int button16 = 0;   //15
	 int button17 = 0;   //17

	final JTextArea commentTextArea = new JTextArea("",40,95);
	
	public GUIInterface() {
		   //Enable auto scroll for receipt panel
		   DefaultCaret caret = (DefaultCaret)commentTextArea.getCaret();
		   caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);		
		}

		  public void newOrder() {
			  prepareGUI();
			  showTextArea();

		  }

		   private void prepareGUI(){
			  commentTextArea.setEditable(false);
			  commentTextArea.setBackground((new Color (253, 255, 225)));
			  commentTextArea.setFont(new Font("Courier", Font.PLAIN, 15));


			  mainFrame = new JFrame("Hotel Database");
			  mainFrame.setSize(870,700);
			  mainFrame.setLayout(new BorderLayout());
			  mainFrame.addWindowListener(new WindowAdapter() {
				 public void windowClosing(WindowEvent windowEvent){
					System.exit(0);
				 }
			  });

			  controlPanel = new JPanel();
			  controlPanel.setLayout(new FlowLayout());

			  final JTextField ccEntry = new JTextField("");
			  ccEntry.setPreferredSize(new Dimension(200, 30));
			  ccEntry.setMaximumSize(new Dimension(500, 30));

			  mainFrame.add(controlPanel, BorderLayout.CENTER);
			  mainFrame.add(ccEntry, BorderLayout.SOUTH);
			 // mainFrame.add(statusLabel);

			  JFrame theFrame = new JFrame("Hotel Actions");
			  theFrame.setDefaultCloseOperation(3);
			  theFrame.setLayout(new BorderLayout());


			  JPanel orderPane = new JPanel();
			  orderPane.setBackground(new Color(222, 222, 221));
			  orderPane.setLayout(new BoxLayout(orderPane, 3));
			  orderPane.setBorder(BorderFactory.createRaisedBevelBorder());

	//1 Make Reservation
			  JButton makeReserve = new JButton("Make Reservation");
				makeReserve.addActionListener(new ActionListener()
				{
				  public void actionPerformed(ActionEvent e)
				  {

				if (button1 % 2 == 0)	{
				makeReserve.setBackground(new Color(246,7,7));
				makeReserve.setOpaque(true);
				button1++;
				 addItem("Room Number, Payment Type, Check In Date, Check Out Date");
				 addItem("Date format: YYYY-MM-DD");
				}
				else {
					button1++;
					makeReserve.setBackground(null);

					 query = ccEntry.getText();
						try{
						 String roomNumber = query.split(",")[0].replaceAll("\\s+","");
						 String paymentType = query.split(",")[1].replaceAll("\\s+","");
						 String checkIn = query.split(",")[2].replaceAll("\\s+","");
						 String checkOut = query.split(",")[3].replaceAll("\\s+","");
						 

						 database = new Database();
						 statement = database.Connect().createStatement();
						 statement.executeUpdate("Insert into Reservation (ReservationID, RoomNum, Payment, CheckIn, CheckOut, updatedAt) value(null,'"+roomNumber+"','"+paymentType+"','"+checkIn+"','"+checkOut+"',null)");

						} 
						catch (MySQLIntegrityConstraintViolationException constr) {
							addItem("Room number must reference an existing room number");
							addItem("Or room number already exists");
						}
						catch (SQLException dateConflict) {
							addItem("Date Insert Conflict");
						}
						 catch (ArrayIndexOutOfBoundsException dateConflict) {
							addItem("No Input");
						}

						catch (Exception a) {
							a.printStackTrace();
							addItem("Input Error");
						}
					}

				}
			});
				// 2 Cancel Reservation
				JButton canReserve = new JButton("Cancel Reservations");
				canReserve.addActionListener(new ActionListener()
				{
				  public void actionPerformed(ActionEvent e)
				  {

				if (button3 % 2 == 0)	{
				canReserve.setBackground(new Color(246,7,7));
				canReserve.setOpaque(true);
				button3++;
				 addItem("Enter ReservationID to Cancel");

				}
				else {
					button3++;
					canReserve.setBackground(null);

					 query = ccEntry.getText();
						try{
						 String ReservationID = query.split(",")[0].replaceAll("\\s+","");
					if (ccEntry.getText() != null){
						 addItem("Reservation Canceled");
					}

						 database = new Database();
						 statement = database.Connect().createStatement();
						 statement.executeUpdate("Delete From Reservation Where ReservationID = '"+ReservationID+"'");
						} catch (SQLException dateConflict){
							addItem("Cancelation Error");
						}

						catch (Exception a){
							a.printStackTrace();
							addItem("Exception");}
				}

				 }
				});

				//3 Display Reservations

			  JButton dispReserve = new JButton("Display Reservations");
			  dispReserve.addActionListener(new ActionListener()
				{
				  public void actionPerformed(ActionEvent e)
				  {

				if (button2 % 2 == 0)	{
				dispReserve.setBackground(new Color(246,7,7));
				dispReserve.setOpaque(true);
				button2++;
				database = new Database();
				try {
				 statement = database.Connect().createStatement();

				 query = "Select * From Reservation";
				 rs = statement.executeQuery(query);
				 addItem("Reservations");
				 addItem("ReservationID | Room Number | Payment Type | Check In | Check Out | UpdatedAt");
				 while (rs.next())
				 {

				   String reserveId = rs.getString("ReservationID");
				   String roomNum = rs.getString("RoomNum");
				   String payment = rs.getString("Payment");
				   Date checkIn = rs.getDate("CheckIn");
				   Date checkOut = rs.getDate("CheckOut");
				   Date update = rs.getDate("updatedAt");

				   // print the results
				   addItem(reserveId+" | "+roomNum+" | "+payment+" | "+checkIn+" | "+checkOut+" | "+ update);

							}
							statement.close();
						} catch (Exception dReserve) {
							dReserve.printStackTrace();
							addItem("Reservation display error");
						}
					}

					else {
						button2++;
						dispReserve.setBackground(null);
						clear();

					}

				}
			});
			  // 4 Create Guest (guest check in)
			  JButton makeGuest = new JButton("Make Guest");
				makeGuest.addActionListener(new ActionListener()
				{
				  public void actionPerformed(ActionEvent e)
				  {

				if (button5 % 2 == 0)	{
				makeGuest.setBackground(new Color(246,7,7));
				makeGuest.setOpaque(true);
				button5++;
				addItem("Guest Check In Enter:");
				addItem("ReservationID, Name, Email");

				}
				else {
					button5++;
					makeGuest.setBackground(null);

					 query = ccEntry.getText();
						try{
						 String ReservationID = query.split(",")[0].replaceAll("\\s+","");
						 String name = query.split(",")[1].trim();
						 String email = query.split(",")[2].replaceAll("\\s+","");

						
						 database = new Database();
						 statement = database.Connect().createStatement();
						 statement.executeUpdate("Insert into Guest (ReservationID, Name, Email) value('"+ReservationID+"','"+name+"','"+email+"')");
						} 
						catch (MySQLIntegrityConstraintViolationException dup){
							addItem("ReservationID already exists in Guests");
							addItem("Or ReservationID does not reference existing ReservationID in Reservation");
						}
						
						catch(ArrayIndexOutOfBoundsException noin) {
							addItem("Input error");
						}
						catch (SQLException guestConflict){
							guestConflict.printStackTrace();
							addItem("Guest Insert Conflict");
						}
						
						

						catch (Exception a){
							a.printStackTrace();
							addItem("Input Error");}
				}

				 }
				});


				// 5 Display Guests
			  JButton dispGuest = new JButton("Display Guests");
			  dispGuest.addActionListener(new ActionListener()
				{
				  public void actionPerformed(ActionEvent e)
				  {

				if (button4 % 2 == 0)	{
				dispGuest.setBackground(new Color(246,7,7));
				dispGuest.setOpaque(true);
				button4++;
				database = new Database();
				addItem("Guests");
				try {
				 statement = database.Connect().createStatement();

				 query = "Select * From Guest";
				 rs = statement.executeQuery(query);
				 addItem("ReservationID | Name | Email");
				 while (rs.next())
				 {

				   String reserveId = rs.getString("ReservationID");
				   String name = rs.getString("Name");
				   String email = rs.getString("Email");

				   // print the results
				   addItem(reserveId+" | "+name+" | "+email);

				 }
				 statement.close();
				} catch (Exception dGuest) {
					dGuest.printStackTrace();
					addItem("Guest display error"); }
				}

				else {
					button4++;
					dispGuest.setBackground(null);
					clear();

				}

				 }
				});
			  //10  Display rooms with a specified occupancy that are occupied between a specified time period
			JButton specRoom = new JButton("Search Reservations");
			specRoom.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					if (button6 % 2 == 0) {
						specRoom.setBackground(new Color(246, 7, 7));
						specRoom.setOpaque(true);
						button6++;
						addItem("Enter desired room size, start date, end date");


					}
					else {
						button6++;
						try {
							 query = ccEntry.getText();
							String roomSize = query.split(",")[0].replaceAll("\\s+", "");
							String start = query.split(",")[1].replaceAll("\\s+","");
							String end = query.split(",")[2].replaceAll("\\s+", "");

							database = new Database();
							statement = database.Connect().createStatement();
							addItem("Reserved Rooms");
							addItem("Room Number | Check In | Check Out | Rate");
							query = "Select RoomNum, CheckIn, CheckOut, Rate From Reservation natural join Room Where RoomSize ='"
									+ roomSize
									+ "'and'"
									+ start
									+ "'<= checkIn and'" + end + "'>= checkOut";
							rs = statement.executeQuery(query);

							while (rs.next()) {

								String number = rs.getString("RoomNum");
								Date checkin = rs.getDate("CheckIn");
								Date checkout = rs.getDate("CheckOut");
								int rate = rs.getInt("Rate");

								// print the results
								addItem(number + " | " + checkin + " | " + checkout
										+ " | " + rate);

							}

							// / 16 Rooms not reserved with a specified room size
							addItem("");
							addItem("Rooms not Reserved");
							addItem("Room Number | Rate | Room Size");
							query = "Select room.RoomNum, Rate, RoomSize From Room left join Reservation on Room.roomNum = Reservation.roomNum Where ReservationID is NULL and roomSize ='"+roomSize+"'";
							rs = statement.executeQuery(query);
							while (rs.next()) {

								String number = rs.getString("RoomNum");
								String rate = rs.getString("Rate");
								int roomS = rs.getInt("RoomSize");

								// print the results
								addItem(number + " | " + rate + " | " + roomS);

							}
							 statement.close();
						} catch (SQLException specRoomConflict) {
							specRoomConflict.printStackTrace();
							addItem("Room Search Error");
						} catch (ArrayIndexOutOfBoundsException specRoomConflict) {

							addItem("No Input");
						}
						catch (NullPointerException specRoomConflict) {
							addItem("No Input");
						}
						catch (Exception a) {
							a.printStackTrace();
							addItem("Search Exception");
						}
						specRoom.setBackground(null);

					}
				}

			});

				//11 Find rooms less than average rate
				 JButton dispRoomsAvg = new JButton("Display Rooms less than average rate");
				 dispRoomsAvg.addActionListener(new ActionListener()
					{
					  public void actionPerformed(ActionEvent e)
					  {

					if (button7 % 2 == 0)	{
					dispRoomsAvg.setBackground(new Color(246,7,7));
					dispRoomsAvg.setOpaque(true);
					button7++;
					database = new Database();
					try {
					 statement = database.Connect().createStatement();

					 query = "Select Room.RoomNum, Rate, RoomSize, CheckIn, CheckOut From Room left join Reservation on Room.roomNum = reservation.roomNum Where rate <= (Select avg(rate) From Room)";
					 rs = statement.executeQuery(query);

					 addItem("Room Number | Rate | Room Size | Check In | Check Out");
					 while (rs.next())
					 {
					   String roomNum = rs.getString("RoomNum");
					   String rate = rs.getString("Rate");
					   String roomSize = rs.getString("RoomSize");
					   Date checkIn = rs.getDate("CheckIn");
					   Date checkOut = rs.getDate("CheckOut");

					   // print the results
					   addItem(roomNum+" | "+rate+" | "+roomSize+" | "+checkIn+" | "+checkOut);

					 }
					 statement.close();
					} catch (Exception dispRoomsAvg) {
						dispRoomsAvg.printStackTrace();
						addItem("Reservation display error"); }
					}

					else {
						button7++;
						dispRoomsAvg.setBackground(null);
						clear();

					}

					 }
					});
				 JButton archive = new JButton("Perform Archive");
				 archive.addActionListener(new ActionListener()
					{
					  public void actionPerformed(ActionEvent e)
					  {
					String inDate = null;
					if (button8 % 2 == 0)	{
					archive.setBackground(new Color(246,7,7));
					archive.setOpaque(true);
					button8++;
					database = new Database();
					try {
						statement = database.Connect().createStatement();
						addItem("Archive");
						addItem("ReservationID | Room Number | Payment Type | Check In | Check Out | updatedAt");
						query = "Select * From Archive";
						rs = statement.executeQuery(query);
						 while (rs.next())
						 {

						   String reserveId = rs.getString("ReservationID");
						   String roomNum = rs.getString("RoomNum");
						   String payment = rs.getString("Payment");
						   Date checkIn = rs.getDate("CheckIn");
						   Date checkOut = rs.getDate("CheckOut");
						   Date update = rs.getDate("updatedAt");

						   // print the results
						   addItem(reserveId+" | "+roomNum+" | "+payment+" | "+checkIn+" | "+checkOut+" | "+ update);

						 }
					 addItem("");
					 addItem("Input cut off date to archive");




					} catch (Exception archiveEx) {
						archiveEx.printStackTrace();
						addItem("No Input"); }
					}

					else {
						button8++;
						archive.setBackground(null);
						clear();
						 String stp = "{call storedProc(?)}";

						inDate = ccEntry.getText();

						 try{
						 CallableStatement call = database.Connect().prepareCall(stp);
						 call.setDate(1, java.sql.Date.valueOf(inDate));
						 call.executeUpdate();
						 }
						 catch (IllegalArgumentException noin){
							 addItem("Input error");
						 }
						 catch (Exception callEx){
							 callEx.printStackTrace();
						 }

					}

					 }
					});

			   // #6 Create a room service request for a room
			   JButton roomService = new JButton("Create room service");
			   roomService.addActionListener(new ActionListener()
			   {
				   public void actionPerformed(ActionEvent e)
				   {

					   if (button9 % 2 == 0)	{
						   roomService.setBackground(new Color(246,7,7));
						   roomService.setOpaque(true);
						   button9++;
						   addItem("Enter new room service:");
						   addItem("RoomNum, Accepted: 1-Yes 0-No, Description");

					   }
					   else {
						   button9++;
						   roomService.setBackground(null);
						   clear();
						   query = ccEntry.getText();
						   try{
							   String RoomNum = query.split(",")[0].replaceAll("\\s+","");
							   String Accepted = query.split(",")[1].replaceAll("\\s+","");
							   String Description = query.split(",")[2];

							   
							   database = new Database();
							   statement = database.Connect().createStatement();
							   statement.executeUpdate("Insert into roomservice (RoomNum, Accepted, Description) value('"+RoomNum+"','"+Accepted+"','"+Description+"')");
						  
						   } 
						   catch (ArrayIndexOutOfBoundsException noin) {
							   addItem("Input format error");
						   }
						   catch (MySQLIntegrityConstraintViolationException contr) {
							   addItem("Room number must reference an existing room number");
						   }
						   catch (SQLException guestConflict){
							  
							   addItem("Room Service Insert Conflict");
						   }
						  

						   catch (Exception a){
							   a.printStackTrace();
							   addItem("Input Error");}
					   }
					  
				   }
			   });


			   // Update room service to accepted given a serviceID
			   JButton updateRoomService = new JButton("Update room service");
			   updateRoomService.addActionListener(new ActionListener()
			   {
				   public void actionPerformed(ActionEvent e)
				   {

					   if (button10 % 2 == 0)	{
						   updateRoomService.setBackground(new Color(246,7,7));
						   updateRoomService.setOpaque(true);
						   button10++;
						   addItem("Enter ServiceID to update room service:");


					   }
					   else {
						   button10++;
						   updateRoomService.setBackground(null);

						   query = ccEntry.getText();
						   try{

							   String ServiceID = query.split(",")[0].replaceAll("\\s+","");


							   addItem("Room Service Updated");
							   database = new Database();
							   statement = database.Connect().createStatement();
							   statement.executeUpdate("Update roomservice Set accepted = 1 Where serviceID = '"+ServiceID+"';");
						   } catch (SQLException guestConflict){
							   guestConflict.printStackTrace();
							   addItem("Room Service Conflict");
						   }

						   catch (Exception a){
							   a.printStackTrace();
							   addItem("Input Error");}
					   }

				   }
			   });


			   // 9 Update room rate of a specific room
			   JButton updateRoomRate= new JButton("Update room rate");
			   updateRoomRate.addActionListener(new ActionListener()
			   {
				   public void actionPerformed(ActionEvent e)
				   {

					   if (button12 % 2 == 0)	{
						   updateRoomRate.setBackground(new Color(246,7,7));
						   updateRoomRate.setOpaque(true);
						   button12++;
						   addItem("Enter new rate for roomNum:");
						   addItem("RoomNum, Rate");


					   }
					   else {
						   button12++;
						   updateRoomRate.setBackground(null);

						   query = ccEntry.getText();
						   try{

							   String roomNum = query.split(",")[0].replaceAll("\\s+","");
							   String rate = query.split(",")[1].replaceAll("\\s+","");


							   addItem("Room rate Updated");
							   database = new Database();
							   statement = database.Connect().createStatement();
							   statement.executeUpdate("update room Set rate = '"+rate+"' Where roomNum = '"+roomNum+"';");
						   } 
						   catch (ArrayIndexOutOfBoundsException noin){
							   addItem("No input");
						   }
						   
						   catch (SQLException guestConflict){
							   guestConflict.printStackTrace();
							   addItem("Room rate update Conflict");
						   }

						   catch (Exception a){
							   a.printStackTrace();
							   addItem("Input Error");}
					   }

				   }
			   });


			   // 12  List rooms with rates in descending order (order by)
			   JButton listRoomDes= new JButton("List room with rates");
			   listRoomDes.addActionListener(new ActionListener()
			   {
				   public void actionPerformed(ActionEvent e)
				   {

					   if (button11 % 2 == 0)	{
						   listRoomDes.setBackground(new Color(246,7,7));
						   listRoomDes.setOpaque(true);
						   button11++;
						   database = new Database();
						   try {
							   statement = database.Connect().createStatement();

							   query = "Select * From Room order by rate";
							   rs = statement.executeQuery(query);
							   addItem("List rooms with rates in descending order");
							   addItem("RoomNum | Rate | RoomSize");
							   while (rs.next())
							   {


								   String roomNum = rs.getString("RoomNum");
								   String rate = rs.getString("Rate");
								   String roomSize = rs.getString("RoomSize");

								   // print the results
								   addItem(roomNum+" | "+rate+" | "+roomSize);

							   }
							   statement.close();
						   } catch (Exception dReserve) {
							   dReserve.printStackTrace();
							   addItem("Room info display error");
						   }
					   }

					   else {
						   button11++;
						   listRoomDes.setBackground(null);
						   clear();

					   }

				   }
			   });

			   //16 Select rooms that have been reserved more than a specified number of times (correlated subquery)
			   JButton specRoom3 = new JButton("Display the popular rooms");
			   specRoom3.addActionListener(new ActionListener() {
				   public void actionPerformed(ActionEvent e) {
					   if (button13 % 2 == 0) {
						   specRoom3.setBackground(new Color(246, 7, 7));
						   specRoom3.setOpaque(true);
						   button13++;
						   addItem("Enter minimum number of reservations for a room");
					   }
					   else {
						   button13++;
						   specRoom3.setBackground(null);
						   try {
							   query = ccEntry.getText();
							   String popular  = query.split(",")[0].replaceAll("\\s+", "");

							   database = new Database();
							   statement = database.Connect().createStatement();
							   addItem("RoomNum | Rate | Room Size | ReservationID | CheckIn | CheckOut | UpdatedAt");

							   query = "Select * From (select* from Room A1 Where " +popular+ " <= (Select count(*) From Reservation A2 Where A1.roomNum = A2.RoomNum)) A3 natural join  Reservation order by roomNum, ReservationId;";
							   rs = statement.executeQuery(query);
							   while (rs.next()) {
								   String roomNum = rs.getString("RoomNum");
								   String rate = rs.getString("Rate");
								   String roomSize = rs.getString("RoomSize");
								   String ReservationID = rs.getString("ReservationID");
								   Date checkIn = rs.getDate("CheckIn");
								   Date checkOut = rs.getDate("CheckOut");
								   Date update = rs.getDate("updatedAt");

								   // print the results
								   addItem(roomNum+" | "+rate+" | "+roomSize+" | "+ReservationID+" |"+checkIn+" | "+checkOut+ " | "+update);

							   }
						   }
						   catch (MySQLSyntaxErrorException noin) {
							   addItem("No input");
						   }
						   catch (Exception dispRooms) {
							   dispRooms.printStackTrace();
							   addItem("Rooms information display error"); 
						   }
					   }
				   }
			   });

			   //8. Return guest(s) who has reserved the room with specific room number

			   JButton dispSepGuest = new JButton("Display Guests in Specific room");
			   dispSepGuest.addActionListener(new ActionListener()
			   {
				   public void actionPerformed(ActionEvent e)
				   {

					   if (button14 % 2 == 0)	{
						   dispSepGuest.setBackground(new Color(246,7,7));
						   dispSepGuest.setOpaque(true);
						   button14++;
						   clear();
						   addItem("Enter room number");
					   }
					   else {
						   button14++;
						   database = new Database();
						   dispSepGuest.setBackground(null);
						   try {
							   query = ccEntry.getText();
							   statement = database.Connect().createStatement();
							   String roomNum = query.split(",")[0].replaceAll("\\s+","");
							   query = "Select * From Guest natural join reservation natural join room Where roomNum = '"
									   + roomNum+"'";
							   rs = statement.executeQuery(query);
							   addItem("ReservationID | Name | Email");
							   while (rs.next())
							   {

								   String reserveId = rs.getString("ReservationID");
								   String name = rs.getString("Name");
								   String email = rs.getString("Email");

								   // print the results
								   addItem(reserveId+" | "+name+" | "+email);

							   }
							   statement.close();
						   } catch (Exception dGuest) {
							   dGuest.printStackTrace();
							   addItem("Guest display error"); }
					   }
				   }
			   });
	//13  Show all RoomService requests
			   JButton dispRoomService = new JButton("Show Room Service");
			   dispRoomService.addActionListener(new ActionListener()
			   {
				   public void actionPerformed(ActionEvent e)
				   {

					   if (button15 % 2 == 0)	{
						   dispRoomService.setBackground(new Color(246,7,7));
						   dispRoomService.setOpaque(true);
						   button15++;
						   database = new Database();
						   addItem("Room Services");
						   try {
							   statement = database.Connect().createStatement();

							   query = "Select * From RoomService Order by accepted";
							   rs = statement.executeQuery(query);
							   addItem("Room number | Accepted 1-Yes 0-No | Description | ServiceID");
							   while (rs.next())
							   {

								   String roomNum = rs.getString("RoomNum");
								   String accepted = rs.getString("Accepted");
								   String description = rs.getString("Description");
								   String service = rs.getString("ServiceID");
								   // print the results
								   addItem(roomNum+" | "+accepted+" | "+description +" | "+service);

							   }
							   statement.close();
						   } catch (Exception dRS) {
							   dRS.printStackTrace();
							   addItem("Room Service display error"); }
					   }
					   else {
						   button15++;
						   dispRoomService.setBackground(null);
						   clear();
					   }
				   }
			   });

	//15.List type of room that only have a specified number of available rooms or less
			   JButton specRoom2 = new JButton("List rooms that have specified number of reservations or less");
				specRoom2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (button16 % 2 == 0) {
							specRoom2.setBackground(new Color(246, 7, 7));
							specRoom2.setOpaque(true);
							button16++;
							clear();
							addItem("Enter the maximum number of reservations for a room.");
						} else {
							button16++;
							specRoom2.setBackground(null);
							query = ccEntry.getText();
							
							try {
								String RoomCount = query.split(",")[0].replaceAll("\\s+", "");

								database = new Database();
								statement = database.Connect().createStatement();
								addItem("Reservation | RoomNum");
								query = "Select count(ReservationID) as Reservation, RoomNum From Reservation Group by RoomNum having Reservation <= '"
										+ RoomCount + "'";
								rs = statement.executeQuery(query);
								while (rs.next()) {
									
									String Reservation = rs.getString("Reservation");
									String RoomNum = rs.getString("RoomNum");

									// print the results
									addItem(Reservation + " | " + RoomNum);
								}
							} catch (SQLException dispRooms) {
								dispRooms.printStackTrace();
								addItem("Rooms display error");
							}
							catch(Exception a)
							{
								addItem("Input error");
							}
						}
					}
				});

// 17  List room serviceID and descriptions for rooms that have not been assigned for 
             	 //repair  yet and is reserved for the specified time period (Intersect query for 
            	//Set operation implemented using IN)
				JButton abc = new JButton("List room serviceID and descriptions for rooms that have not been assigned for \n" + 
						"repair yet and is reserved for the specified time period");
				abc.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (button17 % 2 == 0) {
							abc.setBackground(new Color(246, 7, 7));
							abc.setOpaque(true);
							button17++;
							clear();
							addItem("Enter the start date, end date");
						} else {
							button17++;
							abc.setBackground(null);
							query = ccEntry.getText();	
							
							try {		
								String StartDate = query.split(",")[0].replaceAll("\\s+", "");
								String EndDate = query.split(",")[1].replaceAll("\\s+", "");
														
								database = new Database();
								statement = database.Connect().createStatement();
								addItem("RoomNum | Description");
								query = "select * from ROOMSERVICE where Accepted = 0 and RoomNum in(select RoomNum from RESERVATION where CheckIn >= '" + StartDate + "' and CheckOut <= '" + EndDate + "')";

								rs = statement.executeQuery(query);
								while (rs.next()) {
									String roomNum = rs.getString("RoomNum");
									String Description = rs.getString("Description");
									String service = rs.getString("ServiceID");
									// print the results
									addItem(roomNum + " | " + Description + " | " + service);
								}
							} 
							catch (ArrayIndexOutOfBoundsException noin){
								   addItem("No input");
							   }
							catch (SQLException abc) {
								abc.printStackTrace();
								addItem("Input Error");						
							}

						}
					}
				});

				
		

				












			   orderPane.add(makeReserve);
			  orderPane.add(canReserve);
			  orderPane.add(dispReserve);
			  orderPane.add(specRoom);
			  orderPane.add(dispGuest);
			  orderPane.add(makeGuest);
			  orderPane.add(dispRoomsAvg);
			  orderPane.add(archive);
			  orderPane.add(roomService);
			  orderPane.add(updateRoomService);
			  orderPane.add(updateRoomRate);
			   orderPane.add(listRoomDes);
			   orderPane.add(specRoom3);
			   orderPane.add(dispSepGuest);
			   orderPane.add(dispRoomService);
			   orderPane.add(specRoom2);
			   orderPane.add(abc);








			   theFrame.add(orderPane, "Center");
			  theFrame.setSize(900,550);
			  theFrame.setLocationRelativeTo(null);
			  theFrame.setVisible(true);
		   }

		   private void showTextArea(){
			 // headerLabel.setText("Place the order once finished");
			  JScrollPane scrollPane = new JScrollPane(commentTextArea);

			  controlPanel.add(scrollPane, BorderLayout.CENTER);

			  mainFrame.setVisible(true);
		   }

	public void addItem(String item) {
		   commentTextArea.append(item+"\n");
		  
	   }
	//clear text from window
	public void clear() {
		   commentTextArea.setText(null);
		   
	   }
}

