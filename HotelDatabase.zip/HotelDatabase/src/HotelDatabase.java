

public class HotelDatabase {
	static GUIInterface gui;
	 
	

		 public HotelDatabase() {
		   gui = new GUIInterface();
	       gui.newOrder();
		 }
          
}
