import java.sql.Connection;
import java.sql.DriverManager;





public class Database {
	
	
	public Connection Connect() {
	Connection conn1 = null;
     String url1 = "jdbc:mysql://localhost:3306/Hotel?autoReconnect=true&useSSL=false";
     String user = "root";
     String password = "902772404";
     try {
     conn1 = DriverManager.getConnection(url1, user, password);
     }
     catch (Exception e) {e.printStackTrace();}
    
     if (conn1 != null) {
         //System.out.println("Connected to the database");
     }
     return conn1;
	}
	
}
