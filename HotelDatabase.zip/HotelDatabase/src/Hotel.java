
public class Hotel {

	
	  public static void main(String[] args) {
		  HotelDatabase hotel = new HotelDatabase();
	  }
}
