import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.text.DefaultCaret;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import java.sql.CallableStatement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class CopyOfGUIInterfaceOwn extends JFrame{
	private JFrame mainFrame;
	private JPanel controlPanel;
	 Database database;
	 String query;
	 String sql;
	 java.sql.PreparedStatement pstmt;
	 java.sql.Statement statement;
	 ResultSet rs;
	 int button1 = 0;
	 int button2 = 0;
	 int button3 = 0;
	 int button4 = 0;
	 int button5 = 0;
	 int button6 = 0;
	 int button7 = 0;
	 int button8 = 0;
	 
	
	 
	 
	 
	final JTextArea commentTextArea = new JTextArea("",40,80);
	
	public CopyOfGUIInterfaceOwn() {
		   //Enable auto scroll for receipt panel
		   DefaultCaret caret = (DefaultCaret)commentTextArea.getCaret();
		   caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);		
	}
	
	  public void newOrder() {
		  prepareGUI();
	      showTextArea();
	      
	  }

	   private void prepareGUI(){
		  commentTextArea.setEditable(false);
		  commentTextArea.setBackground((new Color (253, 255, 225)));
		  commentTextArea.setFont(new Font("Courier", Font.PLAIN, 15));
		  
		 
	      mainFrame = new JFrame("Hotel Database");
	      mainFrame.setSize(770,700);
	      mainFrame.setLayout(new BorderLayout());
	      mainFrame.addWindowListener(new WindowAdapter() {
	         public void windowClosing(WindowEvent windowEvent){
	            System.exit(0);
	         }        
	      });    
	        
	      controlPanel = new JPanel();
	      controlPanel.setLayout(new FlowLayout());
	      
	      final JTextField ccEntry = new JTextField("");
	      ccEntry.setPreferredSize(new Dimension(200, 30));
	      ccEntry.setMaximumSize(new Dimension(500, 30));
	  
	      mainFrame.add(controlPanel, BorderLayout.CENTER);
	      mainFrame.add(ccEntry, BorderLayout.SOUTH);
	     // mainFrame.add(statusLabel);
	      
	      JFrame theFrame = new JFrame("Hotel Actions");
	      theFrame.setDefaultCloseOperation(3);
	      theFrame.setLayout(new BorderLayout());
	      
	      
	      JPanel orderPane = new JPanel();
	      orderPane.setBackground(new Color(222, 222, 221));
	      orderPane.setLayout(new BoxLayout(orderPane, 3));
	      orderPane.setBorder(BorderFactory.createRaisedBevelBorder());
	      
//1 Make Reservation	      
	      JButton makeReserve = new JButton("Make Reservation");
		    makeReserve.addActionListener(new ActionListener()
		    {
		      public void actionPerformed(ActionEvent e)
		      {
		    	
		    if (button1 % 2 == 0)	{ 
		    makeReserve.setBackground(new Color(246,7,7));
		    makeReserve.setOpaque(true);
		    button1++;
		     addItem("Room Number, Payment Type, Check In Date, Check Out Date");
		     addItem("Date format: YYYY-MM-DD");
		    }
		    else {
		    	button1++;
		    	makeReserve.setBackground(null);
		    	
		    	 query = ccEntry.getText();	
			    	try{
			    	 String roomNumber = query.split(",")[0].replaceAll("\\s+","");
			    	 String paymentType = query.split(",")[1].replaceAll("\\s+","");
			    	 String checkIn = query.split(",")[2].replaceAll("\\s+","");
			    	 String checkOut = query.split(",")[3].replaceAll("\\s+","");
			    	 addItem("Reservation added");
			    	 
			    	 database = new Database();
			    	 statement = database.Connect().createStatement();
			    	 statement.executeUpdate("Insert into Reservation (ReservationID, RoomNum, Payment, CheckIn, CheckOut, updatedAt) value(null,'"+roomNumber+"','"+paymentType+"','"+checkIn+"','"+checkOut+"',null)");
			    	
					} catch (SQLException dateConflict) {
						addItem("Date Insert Conflict");
					} catch (ArrayIndexOutOfBoundsException dateConflict) {
						addItem("No Input");
					}

					catch (Exception a) {
						a.printStackTrace();
						addItem("Input Error");
					}
				}

			}
		});
		    // 2 Cancel Reservation
		    JButton canReserve = new JButton("Cancel Reservations");
		    canReserve.addActionListener(new ActionListener()
		    {
		      public void actionPerformed(ActionEvent e)
		      {
		    	
		    if (button3 % 2 == 0)	{ 
		    canReserve.setBackground(new Color(246,7,7));
		    canReserve.setOpaque(true);
		    button3++;
		     addItem("Enter ReservationID to Cancel");
		   
		    }
		    else {
		    	button3++;
		    	canReserve.setBackground(null);
		    	
		    	 query = ccEntry.getText();	
			    	try{
			    	 String ReservationID = query.split(",")[0].replaceAll("\\s+","");
			    if (ccEntry.getText() != null){
			    	 addItem("Reservation Canceled");
			    }
			    	 
			    	 database = new Database();
			    	 statement = database.Connect().createStatement();
			    	 statement.executeUpdate("Delete From Reservation Where ReservationID = '"+ReservationID+"'");
			    	} catch (SQLException dateConflict){
			    		addItem("Cancelation Error");
			    	}
			    	
			    	catch (Exception a){
			    		a.printStackTrace();
			    		addItem("Exception");}	
		    }
		        
		     }
		    });
		    
		    //3 Display Reservations
		    
		  JButton dispReserve = new JButton("Display Reservations");
		  dispReserve.addActionListener(new ActionListener()
		    {
		      public void actionPerformed(ActionEvent e)
		      {
		    	
		    if (button2 % 2 == 0)	{ 
		    dispReserve.setBackground(new Color(246,7,7));
		    dispReserve.setOpaque(true);
		    button2++;
		    database = new Database();
		    try {
	    	 statement = database.Connect().createStatement();
	    	 
	    	 query = "Select * From Reservation";
	    	 rs = statement.executeQuery(query);
	    	 addItem("Reservations");
	    	 addItem("ReservationID | Room Number | Payment Type | Check In | Check Out | Updated At");
	    	 while (rs.next())
	         {
	        
	           String reserveId = rs.getString("ReservationID");
	           String roomNum = rs.getString("RoomNum");
	           String payment = rs.getString("Payment");
	           Date checkIn = rs.getDate("CheckIn");
	           Date checkOut = rs.getDate("CheckOut");
	           Date update = rs.getDate("updatedAt");
	           
	           // print the results
	           addItem(reserveId+" | "+roomNum+" | "+payment+" | "+checkIn+" | "+checkOut+" | "+ update);

						}
						statement.close();
					} catch (Exception dReserve) {
						dReserve.printStackTrace();
						addItem("Reservation display error");
					}
				}

				else {
					button2++;
					dispReserve.setBackground(null);
					clear();

				}

			}
		});
		  // 4 Create Guest (guest check in)
		  JButton makeGuest = new JButton("Make Guest");
		    makeGuest.addActionListener(new ActionListener()
		    {
		      public void actionPerformed(ActionEvent e)
		      {
		    	
		    if (button5 % 2 == 0)	{ 
		    makeGuest.setBackground(new Color(246,7,7));
		    makeGuest.setOpaque(true);
		    button5++;
		    addItem("Guest Check In Enter:");
		    addItem("ReservationID, Name, Email");
		     
		    }
		    else {
		    	button5++;
		    	makeGuest.setBackground(null);
		    	
		    	 query = ccEntry.getText();	
			    	try{
			    	 String ReservationID = query.split(",")[0].replaceAll("\\s+","");
			    	 String name = query.split(",")[1].trim();
			    	 String email = query.split(",")[2].replaceAll("\\s+","");
			    	 
			    	 addItem("Guest Entered");
			    	 database = new Database();
			    	 statement = database.Connect().createStatement();
			    	 statement.executeUpdate("Insert into Guest (ReservationID, Name, Email) value('"+ReservationID+"','"+name+"','"+email+"')");
			    	} catch (SQLException guestConflict){
			    		guestConflict.printStackTrace();
			    		addItem("Guest Insert Conflict");
			    	}
			    	
			    	catch (Exception a){
			    		a.printStackTrace();
			    		addItem("Input Error");}	
		    }
		        
		     }
		    });
		  
		  
		    // 5 Display Guests
		  JButton dispGuest = new JButton("Display Guests");
		  dispGuest.addActionListener(new ActionListener()
		    {
		      public void actionPerformed(ActionEvent e)
		      {
		    	
		    if (button4 % 2 == 0)	{ 
		    dispGuest.setBackground(new Color(246,7,7));
		    dispGuest.setOpaque(true);
		    button4++;
		    database = new Database();
		    addItem("Guests");
		    try {
	    	 statement = database.Connect().createStatement();
	    	 
	    	 query = "Select * From Guest";
	    	 rs = statement.executeQuery(query);
	    	 addItem("ReservationID | Name | Email");
	    	 while (rs.next())
	         {
	        
	           String reserveId = rs.getString("ReservationID");
	           String name = rs.getString("Name");
	           String email = rs.getString("Email");
	         
	           // print the results
	           addItem(reserveId+" | "+name+" | "+email);
	    	 
	         }
	    	 statement.close();
		    } catch (Exception dGuest) {
		    	dGuest.printStackTrace();
		    	addItem("Guest display error"); }
		    }
		    
		    else {
		    	button4++;
		    	dispGuest.setBackground(null);
		    	clear();
		    	
		    }
		        
		     }
		    });
		  //11  Display rooms with a specified occupancy that are occupied between a specified time period
		JButton specRoom = new JButton("Search Reservations");
		specRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (button6 % 2 == 0) {
					specRoom.setBackground(new Color(246, 7, 7));
					specRoom.setOpaque(true);
					button6++;
					addItem("Enter desired room size, start date, end date");

					
				}
				else {
					button6++;
					try {
						 query = ccEntry.getText();	
						String roomSize = query.split(",")[0].replaceAll("\\s+", "");
						String start = query.split(",")[1].replaceAll("\\s+","");
						String end = query.split(",")[2].replaceAll("\\s+", "");

						database = new Database();
						statement = database.Connect().createStatement();
						addItem("Reserved Rooms");
						addItem("Room Number | Check In | Check Out | Rate");
						query = "Select RoomNum, CheckIn, CheckOut, Rate From Reservation natural join Room Where RoomSize ='"
								+ roomSize
								+ "'and'"
								+ start
								+ "'<= checkIn and'" + end + "'>= checkOut";
						rs = statement.executeQuery(query);

						while (rs.next()) {

							String number = rs.getString("RoomNum");
							Date checkin = rs.getDate("CheckIn");
							Date checkout = rs.getDate("CheckOut");
							int rate = rs.getInt("Rate");

							// print the results
							addItem(number + " | " + checkin + " | " + checkout
									+ " | " + rate);

						}
						
						// / 16 Rooms not reserved
						addItem("");
						addItem("Rooms not Reserved");
						addItem("Room Number | Rate | Room Size");
						query = "Select room.RoomNum, Rate, RoomSize From Room left join Reservation on Room.roomNum = Reservation.roomNum Where ReservationID is NULL and roomSize ='"+roomSize+"'";
						rs = statement.executeQuery(query);
						while (rs.next()) {

							String number = rs.getString("RoomNum");
							String rate = rs.getString("Rate");
							int roomS = rs.getInt("RoomSize");

							// print the results
							addItem(number + " | " + rate + " | " + roomS);

						}
						 statement.close();
					} catch (SQLException specRoomConflict) {
						specRoomConflict.printStackTrace();
						addItem("Room Search Error");
					} catch (ArrayIndexOutOfBoundsException specRoomConflict) {

						addItem("No Input");
					}
					catch (NullPointerException specRoomConflict) {
						addItem("No Input");
					}
					catch (Exception a) {
						a.printStackTrace();
						addItem("Search Exception");
					}
					specRoom.setBackground(null);
			    	
			    }
			}

		});
		
		
		 
		

		    //15 Find rooms less than average rate
	    	 JButton dispRoomsAvg = new JButton("Display Rooms less than average rate");
	    	 dispRoomsAvg.addActionListener(new ActionListener()
			    {
			      public void actionPerformed(ActionEvent e)
			      {
			    	
			    if (button7 % 2 == 0)	{ 
			    dispRoomsAvg.setBackground(new Color(246,7,7));
			    dispRoomsAvg.setOpaque(true);
			    button7++;
			    database = new Database();
			    try {
		    	 statement = database.Connect().createStatement();
		    	 
		    	 query = "Select Room.RoomNum, Rate, RoomSize, CheckIn, CheckOut From Room left join Reservation on Room.roomNum = reservation.roomNum Where rate <= (Select avg(rate) From Room)";
		    	 rs = statement.executeQuery(query);
		    	
		    	 addItem("Room Number | Rate | Room Size | Check In | Check Out");
		    	 while (rs.next())
		         {
		           String roomNum = rs.getString("RoomNum");
		           String rate = rs.getString("Rate");
		           String roomSize = rs.getString("RoomSize");      
		           Date checkIn = rs.getDate("CheckIn");
		           Date checkOut = rs.getDate("CheckOut");
		           
		           // print the results
		           addItem(roomNum+" | "+rate+" | "+roomSize+" | "+checkIn+" | "+checkOut);
		    	 
		         }
		    	 statement.close();
			    } catch (Exception dispRoomsAvg) {
			    	dispRoomsAvg.printStackTrace();
			    	addItem("Reservation display error"); }
			    }
			    
			    else {
			    	button7++;
			    	dispRoomsAvg.setBackground(null);
			    	clear();

			    }
			        
			     }
			    });
	    	 JButton archive = new JButton("Perform Archive");
	    	 archive.addActionListener(new ActionListener()
			    {
			      public void actionPerformed(ActionEvent e)
			      {
			    String inDate = null;
			    if (button8 % 2 == 0)	{ 
			    archive.setBackground(new Color(246,7,7));
			    archive.setOpaque(true);
			    button8++;
			    database = new Database();
			    try {
			    	statement = database.Connect().createStatement();
					addItem("Archive");
					addItem("ReservationID | Room Number | Payment Type | Check In | Check Out | updatedAt");
					query = "Select * From Archive";
					rs = statement.executeQuery(query);		
			    	 while (rs.next())
			         {
			        
			           String reserveId = rs.getString("ReservationID");
			           String roomNum = rs.getString("RoomNum");
			           String payment = rs.getString("Payment");
			           Date checkIn = rs.getDate("CheckIn");
			           Date checkOut = rs.getDate("CheckOut");
			           Date update = rs.getDate("updatedAt");
			           
			           // print the results
			           addItem(reserveId+" | "+roomNum+" | "+payment+" | "+checkIn+" | "+checkOut+" | "+ update);
			    	 
			         }
			     addItem("");
		    	 addItem("Input cut off date to archive");
		    	 
			    } catch (Exception archiveEx) {
			    	archiveEx.printStackTrace();
			    	addItem("No Input"); }
			    }
			    
			    else {
			    	button8++;
			    	archive.setBackground(null);
			    	 String stp = "{call storedProc(?)}";
			    	 
			    	inDate = ccEntry.getText();
			    	
			    	 try{ 
			    	 CallableStatement call = database.Connect().prepareCall(stp);
			    	 call.setDate(1, java.sql.Date.valueOf(inDate));
			    	 call.executeUpdate();
			    	 } catch (Exception callEx){
			    		 callEx.printStackTrace();
			    	 }

			    }
			        
			     }
			    });
		  
		  
	      orderPane.add(makeReserve);
	      orderPane.add(canReserve);
	      orderPane.add(dispReserve);
	      orderPane.add(specRoom);
	      orderPane.add(dispGuest);
	      orderPane.add(makeGuest);  
	      orderPane.add(dispRoomsAvg);
	      orderPane.add(archive);
	      
	      
	      
	      theFrame.add(orderPane, "Center");
	      theFrame.setSize(400,400);
	      theFrame.setLocationRelativeTo(null);
	      theFrame.setVisible(true);
	   }

	   private void showTextArea(){
	     // headerLabel.setText("Place the order once finished");       
	      JScrollPane scrollPane = new JScrollPane(commentTextArea);    
	    
	      controlPanel.add(scrollPane, BorderLayout.CENTER);  
	    
	      mainFrame.setVisible(true);  
	   }

	public void addItem(String item) {
		   commentTextArea.append(item+"\n");
		  
	   }
	//clear text from window
	public void clear() {
		   commentTextArea.setText(null);
		   
	   }
}
