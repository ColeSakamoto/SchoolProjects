
public class GameBoard {

	int lastRow = 0;
	int lastCol = 0;
	int boardSize = 0;
	int conToWin = 0;
	int lastClient = 0; //Change last made by player 1 or 2?
	
	public GameBoard(int boardSize, int conToWin){
		this.boardSize = boardSize;
		this.conToWin = conToWin;
	}
	
	public void setLastMove(int row, int col){
		this.lastRow = row;
		this.lastCol = col;
	}
	
	public int getlastRow(){
		return this.lastRow;
	}
	public int getlastCol(){
		return this.lastCol;
	}
	public int getboardSize(){
		return this.boardSize;
	}
	public int getconToWin(){
		return this.conToWin;
	}
	
}
