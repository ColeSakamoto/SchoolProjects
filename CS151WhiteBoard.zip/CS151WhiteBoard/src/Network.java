
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;

import javax.swing.*;

import java.util.*;
import java.io.*;
import java.net.*;

public class Network extends JFrame{
    private JTextArea textArea;
    private JTextField field;
    private JLabel status;
    protected boolean connectionValid = true;
    private Canvas netCanvas;
    private JFrame netFrame;
    private JPanel netPanel;
    private DShape[] shapes;
    private Graphics2D graphic;
    private Image image;
    protected boolean vis = true;
    protected String host = "";
    protected boolean hostMatch = false;
    Graphics2D clientG;
    
     // The are thread inner classes to handle
     // the networking.
    private ClientHandler clientHandler;
    private ServerAccepter serverAccepter;
     // List of object streams to which we send data
    private java.util.List<ObjectOutputStream> outputs =
        new ArrayList<ObjectOutputStream>();
    public static void main(String[] args) {
         // Prefer the "native" look and feel.
         try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
         } catch (Exception ignored) { 
         } 
     }
    public Network() {
     setTitle("Ticker");
     JComponent box = new JPanel();
     textArea = new JTextArea(20, 20);
   
     netFrame = new JFrame("netWhiteBoard");
     netFrame.setLayout(new BorderLayout());
     
     netPanel = new JPanel(new FlowLayout());
          
	 netCanvas = new Canvas("netCanvas", 400, 400, Color.white);
	 netCanvas.setVisible(true);
	 netCanvas.canvas.removeMouseListener(netCanvas);
	 netCanvas.canvas.removeMouseMotionListener(netCanvas);
	 
	 netFrame.add(netCanvas.getPanel(), "Center");    
     netFrame.setSize(450, 480);

     field = new JTextField(15);   // For input
     JPanel panel = new JPanel();
     panel.setMinimumSize(new Dimension(200, 30));
     panel.add(field);  
     
     status = new JLabel();
     netFrame.add(netPanel,"South");
 }
    
    public void updateShapes(DShape[] as) {
    	shapes = as;    	    	
    }
    
    public void sendIt() {
    	doSend();
    }
    public void setNetVisible(boolean bool) {
    	netPanel.setVisible(bool);
        netFrame.setVisible(bool);
    }
    
 // Struct object just used for communication -- sent on the object stream.
 // Declared "static", so does not contain a pointer to the outer object.
 // Bean style, set up for xml encode/decode.
    public static class Message {
        public String text;
        public Date date;
        
        public DShape[] shapes;
        
        public Message() {
            text = null;
            date = null;
            shapes = null;
        }

        public DShape[] getShape() {
        	return shapes;
        }
        
        public void setShapes(DShape[] shape) {
        	this.shapes = shape;
        }
        
        public String getText() {
            return text;
        }
        public void setText(String text) {
            this.text = text;
        }

        public Date getDate() { 
            return date;
        }
        public void setDate(Date date) {
            this.date = date;
        }
        public String toString() {
            return "message: " + text;
        }
    }
    // Appends a message to the local GUI (must be on swing thread)
    public void sendLocal(Message message) {
    	
    	BufferedImage image = new BufferedImage(400, 400, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, 400, 400);
       
        DShape[] inShapes = null;        
        inShapes = message.getShape();
   	 
    	for (DShape in : inShapes) {
   		     in.paintComponent(g);
        }
    	g.dispose();
   	 	netCanvas.drawImage((Image)image, 0, 0);
    }
    // Initiate message send -- send both local annd remote (must be on swing thread)
    // Wired to text field.
    public void doSend() {
        Message message = new Message();
        message.setText(field.getText());      
        message.setShapes(shapes);
//        System.out.print("Message "+ message);     
        message.setDate(new Date());
        sendLocal(message);
        sendRemote(message);;
    }
    // Client runs this to handle incoming messages
    // (our client only uses the inputstream of the connection)
    private class ClientHandler extends Thread {
         private String name;
         private int port;
         ClientHandler(String name, int port) {
             this.name = name;
             this.port = port;
         }
     // Connect to the server, loop getting messages
         public void run() {
             try {
                 // make connection to the server name/port
            	 
                 Socket toServer = new Socket(name, port);
                 // get input stream to read from server and wrap in object input stream
                 ObjectInputStream in = new ObjectInputStream(toServer.getInputStream());
//                 System.out.println("client: connected!");
 //                System.out.println("Object Stream: "+in.toString());
                 while (true) {       	 
                     // Get the xml string, decode to a Message object.
                     // Blocks in readObject(), waiting for server to send something.
                     String xmlString = (String) in.readObject();
                     
                     XMLDecoder decoder = new XMLDecoder(new ByteArrayInputStream(xmlString.getBytes()));
                     Message message = (Message) decoder.readObject();
                     
                     
//                    System.out.println("client: read "+ message);
                     invokeToGUI(message);
                 }
             }
             catch (ConnectException e) {
            	 System.out.print("Invalid Connection");
            	 connectionValid = false;
             }
             
             catch (Exception ex) { // IOException and ClassNotFoundException
                ex.printStackTrace();
             }
             // Could null out client ptr.
             // Note that exception breaks out of the while loop,
             // thus ending the thread.
        }
    } 
    // Given a message, puts that message in the local GUI.
    // Can be called by any thread.
    public void invokeToGUI(Message message) {
        final Message temp = message;
        
        
        
//        System.out.println("Message recieved: "+ message);
        SwingUtilities.invokeLater( new Runnable() {
            public void run() {
                status.setText("Client receive");              
                sendLocal(temp);
            }
        });
    }
    // Sends a message to all of the outgoing streams.
    // Writing rarely blocks, so doing this on the swing thread is ok,
    // although could fork off a worker to do it.
    public synchronized void sendRemote(Message message) {
        status.setText("Server send");
//        System.out.println("server: send " + message);

        // Convert the message object into an xml string.
        OutputStream memStream = new ByteArrayOutputStream();
        XMLEncoder encoder = new XMLEncoder(memStream);
        encoder.writeObject(message);
        encoder.close();
        String xmlString = memStream.toString();
        // Now write that xml string to all the clients.
        Iterator<ObjectOutputStream> it = outputs.iterator();
        while (it.hasNext()) {
            ObjectOutputStream out = it.next();
            try {
                out.writeObject(xmlString);
                out.flush();
            }
            catch (Exception ex) {
                ex.printStackTrace();
                it.remove();
                // Cute use of iterator and exceptions --
                // drop that socket from list if have probs with it
            }
        }
    }
    // Adds an object stream to the list of outputs
    // (this and sendToOutputs() are synchronzied to avoid conflicts)
    public synchronized void addOutput(ObjectOutputStream out) {
        outputs.add(out);
        
        
    }
    // Server thread accepts incoming client connections
    class ServerAccepter extends Thread {
        private int port;
        ServerAccepter(int port) {
            this.port = port;
        }
        public void run() {
            try {
                ServerSocket serverSocket = new ServerSocket(port);
                while (true) {
                    Socket toClient = null;
                    // this blocks, waiting for a Socket to the client
                    toClient = serverSocket.accept();
//                   System.out.println("server: got client");
                    
                // Get an output stream to the client, and add it to
                    // the list of outputs
                    // (our server only uses the output stream of the connection)
                    addOutput(new ObjectOutputStream(toClient.getOutputStream()));
                }         
            } 
            catch(BindException e) {
           	 System.out.println("Only 1 server allowed");
            }
            catch (IOException ex) {
                ex.printStackTrace(); 
            }
            catch(IllegalArgumentException w)
            {
            	System.out.println("Invalid Entry");
            }
        }
    }

    // Starts the sever accepter to catch incoming client connections.
    // Wired to Server button.
    public void doServer() {
       // status.setText("Start server");
        String result = JOptionPane.showInputDialog("Run server on port", "40005");
        if (result!=null) {
//            System.out.println("server: start");
        	try 
        	{
                serverAccepter = new ServerAccepter(Integer.parseInt(result.trim()));
                serverAccepter.start();
        	}
        	catch (NumberFormatException e)
        	{
        		System.out.println("Invalid Server input");
        		return;
        	}

        }
    }
    // Runs a client handler to connect to a server.
    // Wired to Client button.
    public void doClient() {
      //  status.setText("Start client");
        String result = JOptionPane.showInputDialog("Connect to host:port", "127.0.0.1:40005");
        if (result!=null) {
            String[] parts = result.split(":");
            host = parts[0];
            
 //           System.out.println("client: start");
            try {
            clientHandler = new ClientHandler(parts[0].trim(), Integer.parseInt(parts[1].trim()));
            }
            catch (NumberFormatException e) {
            	System.out.println("Invalid port");
            	return;            	
            }
            catch(ArrayIndexOutOfBoundsException e)
            {
            	System.out.println("Invalid entry");
            	return;
            }
            clientHandler.start();
            if(host.equals("127.0.0.1")){           	
            	sendIt();
            }
        }
    }
}