import java.awt.Color;

public class Tester {
	
	public static void main(String []args)
	{		
//		DShape y = new DShape();
//		y.createRect();
//		y.createOval();
		
//		DShapeModel x = new DShapeModel();
	}

}
