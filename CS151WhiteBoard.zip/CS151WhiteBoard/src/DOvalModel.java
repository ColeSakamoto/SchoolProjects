import java.awt.Color;

public class DOvalModel extends DShapeModel{
	int x;
	int y ;
	int width;
	int height;
	Color myColor;
	
	public DOvalModel(DShape shape) {
		super(shape);
	}
	public void  setColor(Color col)
	{
		myColor = col;
	}

	@Override
	public void setX(int num) {
		// TODO Auto-generated method stub
		x = num;
	}

	@Override
	public int getX() {
		// TODO Auto-generated method stub
		return x;
	}

	@Override
	public void setY(int num) {
		// TODO Auto-generated method stub
		y = num;
		
	}

	@Override
	public int getY() {
		// TODO Auto-generated method stub
		return y;
	}

	@Override
	public void setWidth(int num) {
		// TODO Auto-generated method stub
		width = num;
	}

	@Override
	public int getWidth() {
		// TODO Auto-generated method stub
		return width;
	}

	@Override
	public void setHeight(int num) {
		// TODO Auto-generated method stub
		height = num;
		
	}

	@Override
	public int getHeight() {
		// TODO Auto-generated method stub
		return height;
	}
	
	@Override
	public Color getColor() {
		// TODO Auto-generated method stub
		return myColor;
	}
}
