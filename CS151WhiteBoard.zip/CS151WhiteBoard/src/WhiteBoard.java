import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class WhiteBoard extends JFrame implements ModelListener {
	JFrame theFrame;
	Canvas theCanvas;
	JPanel thePanel;
	DShape[] shapes;

	JFrame colorFrame; // the set color frame

	Network[] clients = new Network[20];
	int clientNum = 0;

	JTable theTable;
	Color shapeColor; // color to set to shape
	DRect rect; // DRect instance
	Doval ellipse; // Oval instance
	DLine myLine;
	DText drawText;
	Object[][] shapeData = {};
	Object rowData[][];
	Object columnNames[] = { "X", "Y", "Width", "Height" };
	Network theNet;
	JTable table;
	JComboBox<String> comboFonts;
	JTextField ccEntry;

	public WhiteBoard() {
		showGUI();
	}

	private void showGUI() {

		theFrame = new JFrame("WhiteBoard");
		theFrame.setDefaultCloseOperation(3);
		theFrame.setLayout(new BorderLayout());

		comboFonts = new JComboBox<String>();
		comboFonts.setMaximumSize(new Dimension(150, 60));

		String fonts[] = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
		for (int i = 0; i < fonts.length; i++) {
			comboFonts.addItem(fonts[i]);
		}

		comboFonts.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (theCanvas.currentShape != null) {

					theCanvas.currentShape.setFont(comboFonts.getSelectedItem().toString());
					theCanvas.eraseNobs();

				}
			}
		});

		table = new JTable(new DefaultTableModel(rowData, columnNames));
		table.setEnabled(false);
		JScrollPane scrollPane = new JScrollPane(table);

		theCanvas = new Canvas("Canvas", 400, 400, Color.white);
		theCanvas.setVisible(true);

		colorFrame = new JFrame("Set Color");
		colorFrame.setLayout(new GridLayout());

		theNet = new Network();
		theNet.vis = false;
		theNet.setNetVisible(false);

		for (int i = 0; i < 20; i++) {
			clients[i] = new Network();
			clients[i].setNetVisible(false);
		}
		JPanel setColor = new JPanel(new GridLayout(4, 4));

		JPanel orderPane = new JPanel();
		JPanel fontPane = new JPanel();
		JPanel setColorPane = new JPanel();

		JPanel tablePane = new JPanel();
		tablePane.setBackground(new Color(222, 222, 218));

		setColorPane.setBackground(new Color(222, 222, 221));
		orderPane.setBackground(new Color(255, 255, 223));
		orderPane.setLayout(new BoxLayout(orderPane, BoxLayout.Y_AXIS));

		GroupLayout layout = new GroupLayout(orderPane);

		final JLabel titleAdd = new JLabel("Add");
		final JTextField fontDetails = new JTextField("Whiteboard");
		fontDetails.setFont(new Font("Courier", 0, 15));

		orderPane.setBorder(BorderFactory.createRaisedBevelBorder());

		JButton rectangle = new JButton("Rectangle");

		// Action for placing a Rectangle
		rectangle.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				Random rand = new Random();

				rect = new DRect();
				int max = 300;
				int min = 1;
				rect.setX(rand.nextInt(max - min + 1) + min);
				rect.setY(rand.nextInt(max - min + 1) + min);
				theCanvas.draw(rect);
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				updateTable();

				shapes = new DShape[theCanvas.lastSpot];
				shapes = theCanvas.getShapes();
				theNet.updateShapes(shapes);
				if (theNet.vis) {
					theNet.sendIt();
				}
			}
		});

		JButton oval = new JButton("Oval");

		oval.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Random rand = new Random();
				ellipse = new Doval();
				int max = 300;
				int min = 1;
				ellipse.setX(rand.nextInt(max - min + 1) + min);
				ellipse.setY(rand.nextInt(max - min + 1) + min);
				theCanvas.draw(ellipse);
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				updateTable();

				shapes = new DShape[theCanvas.lastSpot];
				shapes = theCanvas.getShapes();
				theNet.updateShapes(shapes);
				if (theNet.vis) {
					theNet.sendIt();
				}
			}
		});

		JButton line = new JButton("Line");

		ccEntry = new JTextField("Text");
		ccEntry.setMaximumSize(new Dimension(150, 60));
		ccEntry.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				if ((theCanvas.currentShape != null)) {
					theCanvas.currentShape.setText(ccEntry.getText());
					theCanvas.eraseNobs();
				}
			}

		});
		line.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Random rand = new Random();
				myLine = new DLine();
				int max = 300;
				int min = 1;
				myLine.setX(rand.nextInt(max - min + 1) + min);
				myLine.setY(rand.nextInt(max - min + 1) + min);
				myLine.setX2(rand.nextInt(max - min + 1) + min);
				myLine.setY2(rand.nextInt(max - min + 1) + min);
				theCanvas.draw(myLine);
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				updateTable();
				shapes = new DShape[theCanvas.lastSpot];
				shapes = theCanvas.getShapes();

				theNet.updateShapes(shapes);
				if (theNet.vis) {
					theNet.sendIt();
				}
			}
		});

		JButton text = new JButton("Text");
		text.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String selectedFont = (String) comboFonts.getSelectedItem();
				String myText = ccEntry.getText();
				drawText = new DText(myText, selectedFont);
				drawText.setX(100);
				drawText.setY(100);
				theCanvas.draw(drawText);

				DefaultTableModel model = (DefaultTableModel) table.getModel();
				updateTable();
				shapes = new DShape[theCanvas.lastSpot];
				shapes = theCanvas.getShapes();

				theNet.updateShapes(shapes);
				if (theNet.vis) {
					theNet.sendIt();
				}
			}
		});
		/////////// Shape Modify Panel
		JButton toFront = new JButton("Move to Front");

		toFront.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					DShape temp = theCanvas.selected.myShape;
					theCanvas.removeShape(theCanvas.selected.myShape);
					theCanvas.draw(temp);
					theCanvas.currentShape = theCanvas.models[theCanvas.lastSpot - 1].myShape;
					theCanvas.eraseNobs();
					shapes = new DShape[theCanvas.lastSpot];
					shapes = theCanvas.getShapes();
					theNet.updateShapes(shapes);
					if (theNet.vis) {
						theNet.sendIt();
					}
				}
			}
		});

		JButton toBack = new JButton("Move To Back");
		toBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					DShape temp = theCanvas.selected.myShape;
					DShape[] move = new DShape[theCanvas.lastSpot + 1];
					theCanvas.removeShape(theCanvas.selected.myShape);
					move[0] = temp;
					for (int i = 0; i < theCanvas.lastSpot; i++) {
						move[i + 1] = theCanvas.models[i].myShape;
					}
					theCanvas.lastSpot = 0;
					theCanvas.models = new DShapeModel[theCanvas.models.length];
					for (int j = 0; j < move.length - 1; j++) {
						theCanvas.draw(move[j]);
					}
					theCanvas.currentShape = theCanvas.models[0].myShape;
					theCanvas.eraseNobs();
					shapes = new DShape[theCanvas.lastSpot];
					shapes = theCanvas.getShapes();
					theNet.updateShapes(shapes);
					if (theNet.vis) {
						theNet.sendIt();
					}
				}
			}
		});

		JButton removeShape = new JButton("Remove Shape");

		removeShape.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theCanvas.removeShape(theCanvas.selected.myShape);
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				updateTable();
				shapes = new DShape[theCanvas.lastSpot];
				shapes = theCanvas.getShapes();
				theNet.updateShapes(shapes);
				if (theNet.vis) {
					theNet.sendIt();
				}
			}
		});

		JButton setC = new JButton("Set Color");
		setC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				colorFrame.add(setColor, "South");
				colorFrame.setSize(200, 200);
				colorFrame.setVisible(true);
			}
		});

		JButton saving = new JButton("Save");
		saving.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String fileName = JOptionPane.showInputDialog("File Name", null);
				if (fileName != null) {
					File f = new File(fileName);
					theCanvas.save(f);
				}
			}
		});

		JButton open = new JButton("Open");
		open.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String fileName = JOptionPane.showInputDialog("File Name", null);
				if (fileName != null) {
					// theCanvas.currentShape = null;
					File f = new File(fileName);
					theCanvas.open(f);
				}

				shapes = new DShape[theCanvas.lastSpot];
				shapes = theCanvas.getShapes();
				theNet.updateShapes(shapes);
				if (theNet.vis) {
					theNet.sendIt();
				}
			}
		}

		);

		JButton SaveIMG = new JButton("Save Image");
		SaveIMG.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String fileName = JOptionPane.showInputDialog("File Name", null);
				if(fileName.contains("\\")){
					System.out.println("Invalid file name. Remove \\");
					return;
				}
				if (fileName != null) {
					fileName= fileName + ".png";
					File f = new File(fileName);
					theCanvas.saveImage(f);
				}
			}
		}
		);

		JButton server = new JButton("Server");
		server.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// theNet = new Network();
				theNet.vis = true;
				shapes = theCanvas.getShapes();
				// theNet.updateCanvas();
				theNet.updateShapes(shapes);
				theNet.doServer();

			}
		}

		);

		JButton client = new JButton("Client");

		client.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				shapes = new DShape[theCanvas.lastSpot];
				shapes = theCanvas.getShapes();
				theNet.updateShapes(shapes);
				if (theNet.vis) {
					theNet.sendIt();

				}

				if (clients[clientNum].connectionValid) {
					clients[clientNum].setNetVisible(true);
					clients[clientNum].updateShapes(shapes);
					clients[clientNum].doClient();
					clientNum++;
				}
			}

		}

		);
		orderPane.add(rectangle);
		orderPane.add(oval);
		orderPane.add(line);
		orderPane.add(text);
		orderPane.add(comboFonts);
		orderPane.add(ccEntry);
		orderPane.add(setC);
		orderPane.add(toFront);
		orderPane.add(toBack);
		orderPane.add(removeShape);
		orderPane.add(saving);
		orderPane.add(open);
		orderPane.add(SaveIMG);
		tablePane.add(client);
		tablePane.add(server);

		JButton black = new JButton();
		black.setBackground(Color.BLACK);
		black.setOpaque(true);
		black.setBorderPainted(false);

		JButton grey = new JButton();
		grey.setBackground(Color.GRAY);
		grey.setOpaque(true);
		grey.setBorderPainted(false);

		JButton blue = new JButton();
		blue.setBackground(Color.BLUE);
		blue.setOpaque(true);
		blue.setBorderPainted(false);

		JButton red = new JButton();
		red.setBackground(Color.RED);
		red.setOpaque(true);
		red.setBorderPainted(false);

		JButton green = new JButton();
		green.setBackground(Color.GREEN);
		green.setOpaque(true);
		green.setBorderPainted(false);

		JButton lime = new JButton();
		lime.setBackground(new Color(171, 255, 0));
		lime.setOpaque(true);
		lime.setBorderPainted(false);

		JButton greenDK = new JButton();
		greenDK.setBackground(new Color(5, 181, 75));
		greenDK.setOpaque(true);
		greenDK.setBorderPainted(false);

		JButton yellow = new JButton();
		yellow.setBackground(Color.YELLOW);
		yellow.setOpaque(true);
		yellow.setBorderPainted(false);

		JButton cyan = new JButton();
		cyan.setBackground(Color.CYAN);
		cyan.setOpaque(true);
		cyan.setBorderPainted(false);

		JButton magenta = new JButton();
		magenta.setBackground(Color.MAGENTA);
		magenta.setOpaque(true);
		magenta.setBorderPainted(false);

		JButton orange = new JButton();
		orange.setBackground(Color.ORANGE);
		orange.setOpaque(true);
		orange.setBorderPainted(false);

		JButton orangeL = new JButton();
		orangeL.setBackground(new Color(255, 162, 0));
		orangeL.setOpaque(true);
		orangeL.setBorderPainted(false);

		JButton orangeR = new JButton();
		orangeR.setBackground(new Color(250, 96, 7));
		orangeR.setOpaque(true);
		orangeR.setBorderPainted(false);

		JButton blueL = new JButton();
		blueL.setBackground(new Color(7, 177, 250));
		blueL.setOpaque(true);
		blueL.setBorderPainted(false);

		JButton blueDK = new JButton();
		blueDK.setBackground(new Color(90, 95, 252));
		blueDK.setOpaque(true);
		blueDK.setBorderPainted(false);

		JButton purple = new JButton();
		purple.setBackground(new Color(104, 7, 250));
		purple.setOpaque(true);
		purple.setBorderPainted(false);

		setColor.add(red);
		setColor.add(orangeR);
		setColor.add(orangeL);
		setColor.add(orange);
		setColor.add(yellow);
		setColor.add(lime);
		setColor.add(green);
		setColor.add(greenDK);
		setColor.add(cyan);
		setColor.add(blueL);
		setColor.add(blueDK);
		setColor.add(blue);
		setColor.add(purple);
		setColor.add(magenta);
		setColor.add(grey);
		setColor.add(black);

		purple.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(new Color(104, 7, 250));
					theCanvas.eraseNobs();
				}
			}
		});
		blueL.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(new Color(7, 177, 250));
					theCanvas.eraseNobs();
				}
			}
		});
		orangeL.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(new Color(255, 162, 0));
					theCanvas.eraseNobs();
				}
			}
		});
		orangeR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(new Color(250, 96, 7));
					theCanvas.eraseNobs();
				}
			}
		});
		orange.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(Color.ORANGE);
					theCanvas.eraseNobs();
				}
			}
		});
		magenta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(Color.MAGENTA);
					theCanvas.eraseNobs();
				}
			}
		});
		cyan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(Color.CYAN);
					theCanvas.eraseNobs();
				}
			}
		});
		black.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(Color.BLACK);
					theCanvas.eraseNobs();
				}
			}
		});
		grey.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(Color.GRAY);
					theCanvas.eraseNobs();
				}
			}
		});
		blue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(Color.BLUE);
					theCanvas.eraseNobs();
				}
			}
		});

		blueDK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(new Color(90, 95, 252));
					theCanvas.eraseNobs();
				}
			}
		});
		red.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(Color.RED);
					theCanvas.eraseNobs();
				}
			}
		});
		green.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(Color.GREEN);
					theCanvas.eraseNobs();
				}
			}
		});
		lime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(new Color(171, 255, 0));
					theCanvas.eraseNobs();
				}
			}
		});
		greenDK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(new Color(5, 181, 75));
					theCanvas.eraseNobs();
				}
			}
		});
		yellow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (theCanvas.selected.myShape != null) {
					theCanvas.selected.myShape.setColor(Color.YELLOW);
					theCanvas.eraseNobs();
				}
			}
		});

		fontPane.add(fontDetails);

		theFrame.add(orderPane, "West");
		theFrame.add(theCanvas.getPanel(), "Center");

		theFrame.add(scrollPane, "East");
		theFrame.add(tablePane, "South");

		theFrame.setSize(1063, 460);
		theFrame.setResizable(false);

		theFrame.setLocationRelativeTo(null);
		theFrame.setVisible(true);
	}

	public void modelChanged() {
		if (theNet.vis) {
			theNet.sendIt();
		}
		updateTable();
		if (theCanvas.currentShape != null 
				&& theCanvas.selected.myShape.getClass().toString().contains("DText")) {
			ccEntry.setEnabled(true);
			comboFonts.setEnabled(true);
			ccEntry.setText(theCanvas.selected.myShape.getText());
			for (int position = 0; position < comboFonts.getItemCount(); position++) {
				if (theCanvas.selected.myShape.getFont().equals(comboFonts.getItemAt(position).toString())) {
					comboFonts.setSelectedIndex(position);
				}
			}

		} else if (theCanvas.currentShape != null) {
			ccEntry.setEnabled(false);
			comboFonts.setEnabled(false);
		} else {
			ccEntry.setEnabled(true);
			comboFonts.setEnabled(true);
		}
	}

	public void updateTable() {
		DShapeModel[] holder = theCanvas.models;

		DefaultTableModel model = (DefaultTableModel) table.getModel();

		model.setRowCount(0);
		for (int i = 0; i < theCanvas.lastSpot; i++) {
			model.addRow(new Object[] { theCanvas.models[i].myShape.getX(), theCanvas.models[i].myShape.getY(),
					theCanvas.models[i].myShape.getWidth(), theCanvas.models[i].myShape.getHeight() });
		}
	}

}
