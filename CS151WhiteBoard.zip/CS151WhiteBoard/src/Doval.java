import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;

public class Doval extends DShape{
	int x;
	int y;	
	int width = 30;	
	int height = 30;	
	Color shapeColor;
	Ellipse2D ellipse;
	
	public Doval()
	{
		shapeColor = Color.GRAY; // Default color
		ellipse = new Ellipse2D.Double(x, y, width, height);
	}		
	
	public Shape returnEllipse()
	{
		return ellipse;
	}
	
	public void setX(int target) {
		
		ellipse.setFrame(target, ellipse.getY(), ellipse.getWidth(), ellipse.getHeight());
	}
	public void setY(int target) {
		
		ellipse.setFrame(ellipse.getX(), target, ellipse.getWidth(), ellipse.getHeight());
	}
	
	public int getX(){
		
		return (int) ellipse.getX();
	}
	public int getY(){
		return (int) ellipse.getY();
	}
	public void setWidth(int target){
		ellipse.setFrame(ellipse.getX(), ellipse.getY(), target, ellipse.getHeight());
	}
	public void setHeight(int target){
		ellipse.setFrame(ellipse.getX(), ellipse.getY(), ellipse.getWidth(), target);
	}
	
	public void setColor(Color color) {
		// set the shape color
		shapeColor = color;
		
	}
	
	public Color getColor()
	{
		return shapeColor;
		
	}
	
	public int getWidth(){
		return (int) ellipse.getFrame().getWidth();
	}
	public int getHeight(){
		return (int) ellipse.getFrame().getHeight();
	}
	
	public boolean contains(int xCoord, int yCoord){
		
		if(xCoord > ellipse.getX() && xCoord < ellipse.getX() + ellipse.getWidth() && yCoord > ellipse.getY() && yCoord < ellipse.getY() + ellipse.getHeight()){
			return true;
		}
		return false;
	}
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setColor(shapeColor);
		g.fillOval((int)ellipse.getX(),(int) ellipse.getY(), (int)ellipse.getWidth(), (int)ellipse.getHeight());
		g.drawOval((int)ellipse.getX(),(int) ellipse.getY(), (int)ellipse.getWidth(), (int)ellipse.getHeight());
		g.setColor(Color.BLACK);
	}
	
}