import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class DLine extends DShape{
	int xOne = 0;
	int yOne = 0;
	int xTwo = 0;
	int yTwo = 0;
	int width = 1;
	int height = 1;
	Color shapeColor;
	
	public DLine(int x, int y, int x2, int y2)
	{
		shapeColor = Color.GRAY; // Default color
		xOne = x;
		yOne = y;
		xTwo = x2;
		yTwo = y2;
		width = (xOne-xTwo);
		height = (yOne-yTwo);
		
	}
	public DLine(){
		shapeColor = Color.GRAY;
	}
	public void setX(int target) {
		
		xOne = target;
	}
	public void setY(int target) {
		
		yOne = target;
	}
	
	public int getX(){
		return xOne;
	}
	public int getY(){
		return yOne;
	}
	public int getHeight(){
		return height;
	}
	public int getWidth(){
		return width;
	}
	public void setHeight(int h){
		height = h;
	}
	public void setWidth(int w){
		width = w;
	}
	public void setX2(int target) {
		
		xTwo = target;
	}
	public void setY2(int target) {
		
		yTwo = target;
	}
	
	public int getX2(){
		return xTwo;
	}
	public int getY2(){
		return yTwo;
	}
	
	public void setColor(Color color) {
		// set the shape color
		shapeColor = color;		
	}	
	public Color getColor()
	{
		return shapeColor;
	}
	public boolean contains(int xCoord, int yCoord){
		if(xOne > xTwo){
			if(yOne > yTwo){
				if(xCoord > xTwo && xCoord < xOne && yCoord > yTwo && yCoord < yOne){
					return true;
				}
			}else{
				if(xCoord > xTwo && xCoord < xOne && yCoord < yTwo && yCoord > yOne){
					return true;
				}
			}
		}else{
			if(yOne > yTwo){
				if(xCoord < xTwo && xCoord > xOne && yCoord > yTwo && yCoord < yOne){
					return true;
				}
			}else{
				if(xCoord < xTwo && xCoord > xOne && yCoord < yTwo && yCoord > yOne){
					return true;
				}
			}
		}
		
		return false;
	}
	
	public void paintComponent(Graphics g){
		width = (xOne-xTwo);
		height = (yOne-yTwo);
		g.setColor(shapeColor);
		g.drawLine(xOne, yOne, xTwo, yTwo);
		g.setColor(Color.BLACK);
	}
}
