import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;

import javax.swing.JButton;

public class DTransform extends JButton{
	Ellipse2D topLeft = new Ellipse2D.Double();
	Ellipse2D topRight = new Ellipse2D.Double();
	Ellipse2D bottomLeft = new Ellipse2D.Double();
	Ellipse2D bottomRight = new Ellipse2D.Double();
	boolean visible = false;
	
	int size = 10;
	double x= 0;
	double y = 0;
	double height = 0;
	double width = 0;
	DShape myShape = null;

	
	DTransform(){
		
	}
	
	DTransform(DShape shape){
		myShape = shape;
		x = shape.getX();
		y = shape.getY();
		width = shape.getWidth();
		height = shape.getHeight();
		topLeft = new Ellipse2D.Double(x-5,y-5,10,10);
		topRight = new Ellipse2D.Double(x+width-5,y-5,10,10);
		bottomLeft = new Ellipse2D.Double(x-5,y+height-5,10,10);
		bottomRight = new Ellipse2D.Double(x+width-5,y+height-5,10,10);
		
		
		//adjusts the knobs for lines
		if(shape.getClass().getName().contains("DLine")){
			bottomRight = new Ellipse2D.Double(shape.getX2()-5,shape.getY2()-5,10,10);
			bottomLeft = topLeft;
			topRight = bottomRight;
		}		
	}
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(Color.WHITE);
		if(visible){
			g2.fill(topLeft);
			g2.fill(topRight);
			g2.fill(bottomLeft);
			g2.fill(bottomRight);
			g2.setColor(Color.BLACK);
			g2.draw(topLeft);
			g2.draw(topRight);
			g2.draw(bottomLeft);
			g2.draw(bottomRight);
		}		
	}	
	public void transform(Ellipse2D.Double nob, int x, int y, int width, int height){
		
	}	
}
