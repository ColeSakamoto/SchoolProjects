import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.event.ChangeEvent;
import javax.swing.event.EventListenerList;

public class DShapeModel extends JButton{
	DShapeModel[] objects;
	DShape myShape;
	int x;
	int y;	
	int width;	
	int height;
	int x2;
	int y2;
	Color myColor;
	Canvas can;
	
	protected List<ModelListener> listeners = new ArrayList<ModelListener>();
	
	 
	 public DShapeModel(DShape shape){
		 myShape = shape;
		 x = shape.getX();
		 y = shape.getY();
		 x2 = shape.getX2();
		 y2 = shape.getY2();
		 width = shape.getWidth();
		 height = shape.getHeight();
		 myColor = shape.getColor();	 
	 }

	public void setX(int num)
	{
		x = num;
	}

	public int getX()
	{
		return x;
	}

	public void setY(int num)
	{
		y = num;
	}

	public int getY()
	{
		return y;
	}
	
	public void setX2(int num){
		x2 = num;
	}
	
	public int getX2(){
		return x2;
	}
	
	public void setY2(int num){
		y2 = num;
	}
	
	public int getY2(){
		return y2;
	}

	public void setWidth(int num)
	{
		width = num;
	}

	public int getWidth()
	{
		return width;
	}

	public void setHeight(int num)
	{
		height = num;
	}

	public int getHeight()
	{
		return height;
	}
	
	public void setColor(Color color)
	{
		myColor = color;
	}
	
	public Color getColor()
	{
		return myColor;
	}
	
	public void addModelListener(ModelListener toAdd){
    	listeners.add(toAdd);
    }

	public void somethingChanged(){
		for(ModelListener ear: listeners){
			ear.modelChanged();
		}
	}
}
