import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.font.FontRenderContext;
import java.awt.font.TextLayout;
import java.awt.geom.Rectangle2D;
import javax.sound.sampled.Clip;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;

public class DText extends DShape{
	int x;
	int y;	
	int width = 200;	
	int height = 50;
	String text;
	String fontName;
	Color myColor;
	Rectangle rect;
	int size = 12;
	int realY;
	int descent;
	Font original;
	Font font;
	
	public DText ()	
	{
		myColor = Color.GRAY;
		rect = new Rectangle(x, y, width, height);
	}
	
	public DText(String theText, String theFont){
		text = theText;
		fontName = theFont;
		myColor = Color.GRAY;
		rect = new Rectangle(x, y, width, height);
	}
	
	public void setX(int target)	{
		rect.x = target;
	}	
	public int getX()	{
		return rect.x;
	}	
	public void setY(int target)	{
		rect.y = target;
	}	
	public int getY()	{
		return rect.y;
	}	
	public void setWidth(int target){
		rect.width = target;
	}	
	public int getWidth(){
		return rect.width;
	}	
	public void setHeight(int target){
		rect.height = target;		
	}
	public int getHeight(){
		return rect.height;
	}	
	public void setText(String target){
		text = target;
		setWidth(300);
	}	
	public String getText()	{
		return text;
	}
	public void setFont(String target){
		fontName = target;
		
	}
	public String getFont(){
		return fontName;
	}
	public void setColor(Color color){
		myColor = color;		
	}
	
	public Color getColor()
	{
		return myColor;
	}
		
	public boolean contains (int xCoord, int yCoord)
	{		
		if(xCoord > rect.x && xCoord < rect.x + rect.width && yCoord > rect.y && yCoord < rect.y + rect.height){
			return true;
		}
		return false;
	}
	public void computeMetrics(Graphics g){
		original = g.getFont();
		FontMetrics fm = g.getFontMetrics();
		
		
		if(font == null){
			font = original;
			descent = fm.getMaxDescent();
		}else{
			font = new Font(getFont(), Font.PLAIN, size);
		
			g.setFont(font);
			fm = g.getFontMetrics();
			descent = fm.getMaxDescent();
		}
		realY = getY() + fm.getAscent();
		while(fm.getHeight() < getHeight() -1|| fm.getHeight()> getHeight()+1){
			
			if(fm.getHeight() < getHeight()-1){
			
				size++;
				font = new Font(getFont(), Font.PLAIN,size);
				g.setFont(font);
				fm = g.getFontMetrics();
				descent = fm.getMaxDescent();
				realY = getY() + fm.getAscent();
				
			}else{
				
				size--;
				font = new Font(getFont(), Font.PLAIN, size);
				g.setFont(font);
				fm = g.getFontMetrics();
				descent = fm.getMaxDescent();
				realY = getY() + fm.getAscent();
			}
		}	
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(myColor);		
		computeMetrics(g);	
		if(getWidth() > g.getFontMetrics().stringWidth(text)){
			setWidth(g.getFontMetrics().stringWidth(text)+10);
		}		
		g.setClip(rect);
		g.drawString(text, getX(), realY);
		g.setFont(original);
		g.setClip(null);
		g.setColor(Color.BLACK);			
	}
}
