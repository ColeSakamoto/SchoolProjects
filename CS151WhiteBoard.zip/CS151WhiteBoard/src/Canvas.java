import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.imageio.ImageIO;

public class Canvas extends JPanel implements MouseMotionListener, MouseListener {

	public JFrame frame;
	protected DShape currentShape;
	protected CanvasPane canvas;
	private Graphics2D graphic;
	private Color backgroundColour;
	private Image canvasImage;
	protected DTransform selected = new DTransform();
	protected DShape[] shapes = new DShape[10];
	protected DShapeModel[] models = new DShapeModel[10];
	protected int lastSpot = 0;
	protected int clickX = 0;
	protected int clickY = 0;
	protected boolean mouseClicked = false;
	protected boolean topLeftClick = false;
	protected boolean topRightClick = false;
	protected boolean bottomLeftClick = false;
	protected boolean bottomRightClick = false;
	protected boolean shapeSelected = false;
	protected boolean canvasChanged = false;
	public WhiteBoard theBoard;

	// selected check
	/**
	 * Create a Canvas with default height, width and background colour (300,
	 * 300, white).
	 * 
	 * @param title
	 *            title to appear in Canvas Frame
	 */
	public Canvas(String title) {

		this(title, 300, 300, Color.white);

	}

	/**
	 * Create a Canvas with default background colour (white).
	 * 
	 * @param title
	 *            title to appear in Canvas Frame
	 * @param width
	 *            the desired width for the canvas
	 * @param height
	 *            the desired height for the canvas
	 */
	public Canvas(String title, int width, int height) {

		this(title, width, height, Color.white);

	}

	/**
	 * TO DO Return current shape object
	 * 
	 */
	public Object getSelectedObject() {

		return currentShape;
	}

	/**
	 * Create a Canvas.
	 * 
	 * @param title
	 *            title to appear in Canvas Frame
	 * @param width
	 *            the desired width for the canvas
	 * @param height
	 *            the desired height for the canvas
	 * @param bgClour
	 *            the desired background colour of the canvas
	 */
	public Canvas(String title, int width, int height, Color bgColour) {

		frame = new JFrame();

		canvas = new CanvasPane();
		frame.setContentPane(canvas);
		frame.setTitle(title);
		canvas.setPreferredSize(new Dimension(width, height));
		backgroundColour = bgColour;

		canvas.addMouseListener(this);

		canvas.addMouseMotionListener(this);

		frame.pack();
	}

	public JPanel getPanel() {
		return canvas;
	}

	/**
	 * Set the canvas visibility and brings canvas to the front of screen when
	 * made visible. This method can also be used to bring an already visible
	 * canvas to the front of other windows.
	 * 
	 * @param visible
	 *            boolean value representing the desired visibility of the
	 *            canvas (true or false)
	 */
	public void setVisible(boolean visible) {
		if (graphic == null) {
			// first time: instantiate the offscreen image and fill it with
			// the background colour
			Dimension size = canvas.getSize();
			canvasImage = canvas.createImage(size.width, size.height);
			graphic = (Graphics2D) canvasImage.getGraphics();
			graphic.setColor(backgroundColour);
			graphic.fillRect(0, 0, size.width, size.height);
			graphic.setColor(Color.black);
		}
		// frame.show();
	}

	/**
	 * Provide information on visibility of the Canvas.
	 * 
	 * @return true if canvas is visible, false otherwise
	 */
	public boolean isVisible() {
		return frame.isVisible();
	}

	/**
	 * Draw a given shape onto the canvas.
	 * 
	 * @param shape
	 *            the shape object to be drawn on the canvas
	 */
	public void draw(DShape shape) {
		if (shape.getClass().toString().contains("DRect")) {
			models[lastSpot] = new DShapeModel(shape);
			models[lastSpot].addModelListener(theBoard);

		} else if (shape.getClass().toString().contains("Doval")) {
			models[lastSpot] = new DShapeModel(shape);
			models[lastSpot].addModelListener(theBoard);

		} else if (shape.getClass().toString().contains("DLine")) {
			models[lastSpot] = new DShapeModel(shape);
			models[lastSpot].addModelListener(theBoard);
		} else if (shape.getClass().toString().contains("DText")) {
			models[lastSpot] = new DShapeModel(shape);
			models[lastSpot].addModelListener(theBoard);
		}
		lastSpot++;

		// Resizes arrays as needed
		if (lastSpot == shapes.length) {
			DShape[] temp = new DShape[lastSpot * 2];
			for (int i = 0; i < lastSpot; i++) {
				temp[i] = shapes[i];
			}
			shapes = new DShape[temp.length];
			for (int j = 0; j < lastSpot; j++) {
				shapes[j] = temp[j];
			}
		}
		if (lastSpot == models.length - 1) {
			DShapeModel[] temp = new DShapeModel[lastSpot * 2];
			for (int i = 0; i < lastSpot; i++) {
				temp[i] = models[i];
			}
			models = new DShapeModel[temp.length];
			for (int j = 0; j < lastSpot; j++) {
				models[j] = temp[j];
			}
		}
		shape.paintComponent(graphic);
		canvas.repaint();
	}

	public void removeShape(DShape shape) {
		for (int i = 0; i < lastSpot; i++) {
			if (models[i].myShape == shape) {
				if (shape == currentShape) {
					currentShape = null;
					selected.myShape = currentShape;
				}
				for (int j = i; j < lastSpot; j++) {
					if (j + 1 != lastSpot) {
						models[j] = models[j + 1];
					} else
						models[j] = null;
				}
				lastSpot--;
				eraseNobs();
				break;
			}
		}

	}

	public void setShapeColor(Color r) {
		graphic.setColor(r);
	}

	/**
	 * Fill the internal dimensions of a given shape with the current foreground
	 * colour of the canvas.
	 * 
	 * @param shape
	 *            the shape object to be filled
	 */
	public void fill(Shape shape) {

		graphic.fill(shape);
		canvas.repaint();
	}

	/**
	 * Erase the whole canvas.
	 */
	public void eraseNobs() {
		Color original = graphic.getColor();
		graphic.setColor(backgroundColour);
		Dimension size = canvas.getSize();
		graphic.fill(new Rectangle(0, 0, size.width, size.height));
		graphic.setColor(original);

		for (int i = 0; i < lastSpot; i++) {
			models[i].myShape.paintComponent(graphic);
		}

		canvasChanged = true;
		canvas.repaint();

		// added so the knobs will be redrawn and not lost while resizing/moving
		if (currentShape != null) {
			selected = new DTransform(currentShape);
			selected.visible = true;
			selected.paintComponent(graphic);
		}
		if (models[0] != null) {
			models[0].somethingChanged();
		}
	}

	/**
	 * Erase a given shape's interior on the screen.
	 * 
	 * @param shape
	 *            the shape object to be erased
	 */
	public void erase(Shape shape) {
		Color original = graphic.getColor();
		graphic.setColor(backgroundColour);
		graphic.fill(shape); // erase by filling background colour
		graphic.setColor(original);
		canvas.repaint();
	}

	/**
	 * Erases a given shape's outline on the screen.
	 * 
	 * @param shape
	 *            the shape object to be erased
	 */
	public void eraseOutline(Shape shape) {
		Color original = graphic.getColor();
		graphic.setColor(backgroundColour);
		graphic.draw(shape); // erase by drawing background colour
		graphic.setColor(original);
		canvas.repaint();
	}

	/**
	 * Draws an image onto the canvas.
	 * 
	 * @param image
	 *            the Image object to be displayed
	 * @param x
	 *            x co-ordinate for Image placement
	 * @param y
	 *            y co-ordinate for Image placement
	 * @return returns boolean value representing whether the image was
	 *         completely loaded
	 */
	public boolean drawImage(Image image, int x, int y) {
		boolean result = graphic.drawImage(image, x, y, null);
		canvas.repaint();
		return result;
	}

	/**
	 * Draws a String on the Canvas.
	 * 
	 * @param text
	 *            the String to be displayed
	 * @param x
	 *            x co-ordinate for text placement
	 * @param y
	 *            y co-ordinate for text placement
	 */
	public void drawString(String text, int x, int y) {
		graphic.drawString(text, x, y);
		canvas.repaint();
	}

	/**
	 * Erases a String on the Canvas.
	 * 
	 * @param text
	 *            the String to be displayed
	 * @param x
	 *            x co-ordinate for text placement
	 * @param y
	 *            y co-ordinate for text placement
	 */
	public void eraseString(String text, int x, int y) {
		Color original = graphic.getColor();
		graphic.setColor(backgroundColour);
		graphic.drawString(text, x, y);
		graphic.setColor(original);
		canvas.repaint();
	}

	/**
	 * Draws a line on the Canvas.
	 * 
	 * @param x1
	 *            x co-ordinate of start of line
	 * @param y1
	 *            y co-ordinate of start of line
	 * @param x2
	 *            x co-ordinate of end of line
	 * @param y2
	 *            y co-ordinate of end of line
	 */
	public void drawLine(int x1, int y1, int x2, int y2) {
		graphic.drawLine(x1, y1, x2, y2);
		canvas.repaint();
	}

	/**
	 * Sets the foreground colour of the Canvas.
	 * 
	 * @param newColour
	 *            the new colour for the foreground of the Canvas
	 */
	public void setForegroundColour(Color newColour) {
		graphic.setColor(newColour);
	}

	/**
	 * Returns the current colour of the foreground.
	 * 
	 * @return the colour of the foreground of the Canvas
	 */
	public Color getForegroundColour() {
		return graphic.getColor();
	}

	/**
	 * Sets the background colour of the Canvas.
	 * 
	 * @param newColour
	 *            the new colour for the background of the Canvas
	 */
	public void setBackgroundColour(Color newColour) {
		backgroundColour = newColour;
		graphic.setBackground(newColour);
	}

	/**
	 * Returns the current colour of the background
	 * 
	 * @return the colour of the background of the Canvas
	 */
	public Color getBackgroundColour() {
		return backgroundColour;
	}
	/**
	 * Sets the size of the canvas.
	 * 
	 * @param width
	 *            new width
	 * @param height
	 *            new height
	 */
	public void setSize(int width, int height) {
		canvas.setPreferredSize(new Dimension(width, height));
		Image oldImage = canvasImage;
		canvasImage = canvas.createImage(width, height);
		graphic = (Graphics2D) canvasImage.getGraphics();
		graphic.drawImage(oldImage, 0, 0, null);
		frame.pack();
	}

	/**
	 * Returns the size of the canvas.
	 * 
	 * @return The current dimension of the canvas
	 */
	public Dimension getSize() {
		return canvas.getSize();
	}

	/**
	 * Waits for a specified number of milliseconds before finishing. This
	 * provides an easy way to specify a small delay which can be used when
	 * producing animations.
	 * 
	 * @param milliseconds
	 *            the number
	 */
	public void wait(int milliseconds) {
		try {
			Thread.sleep(milliseconds);
		} catch (Exception e) {
			// ignoring exception at the moment
		}
	}

	public void save(File file) {
		try {
			XMLEncoder Out = new XMLEncoder(new BufferedOutputStream(new FileOutputStream(file)));

			DShape[] ShapeArray = new DShape[lastSpot];
			for (int i = 0; i < lastSpot; i++) {
				ShapeArray[i] = models[i].myShape;
			}
			Out.writeObject(ShapeArray);
			Out.close();

		} catch (IOException e) {
			// e.printStackTrace();
			System.out.println("Unable to save");
		}
	}

	public void saveImage(File file) {

		// Create an image bitmap, same size as ourselves
		BufferedImage image = new BufferedImage(400, 400, BufferedImage.TYPE_INT_RGB);

		Graphics2D g = image.createGraphics();

		g.setColor(Color.WHITE);
		g.fillRect(0, 0, 400, 400);
		for (int i = 0; i < lastSpot; i++) {
			models[i].myShape.paintComponent(g);
		}
		g.dispose();

		if(file.getName().equals("")){
			System.out.println("Filename empty");
			return;
		}
		
				
		try {

			javax.imageio.ImageIO.write(image, "PNG", file);
		} 
		catch (FileNotFoundException e)
		{
			System.out.println("File not found");
		}	
		catch (IOException ex) {
			ex.printStackTrace();
		}


	}

	public void open(File file) {
		DShape[] shapeArray = null;

		try {
			XMLDecoder In = new XMLDecoder(new BufferedInputStream(new FileInputStream(file)));
			shapeArray = (DShape[]) In.readObject();
			In.close();

			// Clear the canvas board for new file and draw the array unto the
			// array
			lastSpot = shapeArray.length;
			models = new DShapeModel[lastSpot * 2];
			for (int i = 0; i < lastSpot; i++) {
				models[i] = new DShapeModel(shapeArray[i]);
				models[i].addModelListener(theBoard);
			}

			currentShape = null;

			eraseNobs();
			canvas.repaint();
		}
		catch (IOException e) {
			System.out.println("File Not Found");
		}
		catch (ArrayIndexOutOfBoundsException e)
		{
			System.out.println("File empty");
		}
		

	}

	public DShape[] getShapes() {
		shapes = new DShape[lastSpot];
		for (int i = 0; i < lastSpot; i++) {
			shapes[i] = models[i].myShape;
		}
		return shapes;
	}

	/************************************************************************
	 * Nested class CanvasPane - the actual canvas component contained in the
	 * Canvas frame. This is essentially a JPanel with added capability to
	 * refresh the image drawn on it.
	 */
	class CanvasPane extends JPanel {
		public void paint(Graphics g) {
			g.drawImage(canvasImage, 0, 0, null);
		}
	}

	public void addController(WhiteBoard ourBoard) {
		theBoard = ourBoard;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

		clickX = e.getX();
		clickY = e.getY();
		for (int i = lastSpot - 1; i >= 0; i--) {

			// This fixes an issue where selecting a knob would accidentally
			// select a shape the knob overlaps

			if (selected.topLeft.contains(clickX, clickY) || selected.topRight.contains(clickX, clickY)
					|| selected.bottomLeft.contains(clickX, clickY) || selected.bottomRight.contains(clickX, clickY)) {
				break;
			}
			if (models[i].myShape.contains(e.getX(), e.getY())) {
				currentShape = models[i].myShape;
				selected = new DTransform(models[i].myShape);
				selected.visible = true;
				selected.paintComponent(graphic);
				canvas.repaint();
				break;
			} else {
				currentShape = null;
				selected.visible = false;
				selected.paintComponent(graphic);
				canvas.repaint();
			}
		}

		if (selected.myShape != null && selected.myShape.contains(clickX, clickY)) {

			shapeSelected = true;
		}
		mouseClicked = true;
		if (selected.topLeft.contains(e.getX(), e.getY())) {
			topLeftClick = true;
		} else if (selected.topRight.contains(e.getX(), e.getY())) {
			topRightClick = true;
		} else if (selected.bottomLeft.contains(e.getX(), e.getY())) {
			bottomLeftClick = true;
		} else if (selected.bottomRight.contains(e.getX(), e.getY())) {
			bottomRightClick = true;
		} else {
			return;
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		mouseClicked = false;
		topLeftClick = false;
		topRightClick = false;
		bottomLeftClick = false;
		bottomRightClick = false;
		shapeSelected = false;
		eraseNobs();
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseDragged(MouseEvent e) {

		// This massive 'IF' loop handles inversions
		if (selected.topLeft.getY() > selected.bottomLeft.getY()
				&& !selected.myShape.getClass().getName().contains("DLine")) {
			if (topLeftClick || bottomLeftClick) {

				topLeftClick = !topLeftClick;
				bottomLeftClick = !bottomLeftClick;
			}
			if (topRightClick || bottomRightClick) {
				topRightClick = !topRightClick;
				bottomRightClick = !bottomRightClick;
			}
		} else if (selected.topLeft.getX() > selected.topRight.getX()
				&& !selected.myShape.getClass().getName().contains("DLine")) {
			if (topLeftClick || topRightClick) {
				topLeftClick = !topLeftClick;
				topRightClick = !topRightClick;
			} else {
				bottomLeftClick = !bottomLeftClick;
				bottomRightClick = !bottomRightClick;
			}
		}

		int x = e.getX();
		int y = e.getY();

		// drag check
		if (!shapeSelected && !topLeftClick && !topRightClick && !bottomLeftClick && !bottomRightClick) {
			return;
		}
		int width = selected.myShape.getWidth();
		int height = selected.myShape.getHeight();
		int i = 0;

		for (i = 0; i < lastSpot; i++) {
			if (selected.myShape == models[i].myShape) {

				currentShape = models[i].myShape; /// get current object (only
													/// works for when mouse is
													/// dragged)
				break; // otherwise returns null
			}

		}

		if (mouseClicked && !topLeftClick && !topRightClick && !bottomLeftClick && !bottomRightClick) {// (Contain
																										// check)

			models[i].myShape.setX((e.getX() - clickX) + models[i].myShape.getX());
			models[i].myShape.setY((e.getY() - clickY) + models[i].myShape.getY());

			// Allows lines to move without distortion
			if (models[i].myShape.getClass().getName().contains("DLine")) {
				models[i].myShape.setX2((e.getX() - clickX) + models[i].myShape.getX2());
				models[i].myShape.setY2((e.getY() - clickY) + models[i].myShape.getY2());
			}
			clickX = e.getX();
			clickY = e.getY();
			eraseNobs();
			canvas.repaint();

		}

		if (topLeftClick) {

			x = e.getX();
			y = e.getY();

			models[i].myShape.setWidth(selected.myShape.getX() - x + width);
			models[i].myShape.setHeight(selected.myShape.getY() - y + height);
			models[i].myShape.setX(x);
			models[i].myShape.setY(y);

			eraseNobs();
			canvas.repaint();
		}

		if (topRightClick) {
			x = e.getX();
			y = e.getY();

			models[i].myShape.setWidth(x - (selected.myShape.getX() + width) + width);
			models[i].myShape.setHeight(selected.myShape.getY() - y + height);

			// handles lines
			if (models[i].myShape.getClass().getName().contains("DLine")) {
				models[i].myShape.setX2(x);
				models[i].myShape.setY2(y);
			} else {
				models[i].myShape.setY(y);
			}
			eraseNobs();
			canvas.repaint();
		}
		if (bottomLeftClick) {
			x = e.getX();
			y = e.getY();

			models[i].myShape.setWidth(selected.myShape.getX() - x + width);
			models[i].myShape.setHeight(y - (selected.myShape.getY() + height) + height);
			models[i].myShape.setX(x);

			eraseNobs();
			canvas.repaint();
		}
		if (bottomRightClick) {
			x = e.getX();
			y = e.getY();

			models[i].myShape.setWidth(x - (selected.myShape.getX() + width) + width);
			models[i].myShape.setHeight(y - (selected.myShape.getY() + height) + height);

			// handles lines
			if (models[i].myShape.getClass().getName().contains("DLine")) {
				models[i].myShape.setX2(x);
				models[i].myShape.setY2(y);
			}
			eraseNobs();
			canvas.repaint();
		}

	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}