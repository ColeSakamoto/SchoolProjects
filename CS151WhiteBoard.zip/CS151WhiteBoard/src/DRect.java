import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class DRect extends DShape {
	int x;
	int y;	
	int width = 30;	
	int height = 30;	
	Color myColor;
	Rectangle rect;
	DRectModel myModel;
	
	public DRect()
	{
		myColor = Color.GRAY; // Default color
		rect = new Rectangle(x, y, width, height);
	}	

	
	public Rectangle returnRect()
	{
		return rect;
	}
	
	public void setX(int target) {
		
		rect.x = target;
	}
	public void setY(int target) {
		
		rect.y = target;
	}
	
	public int getX(){
		return rect.x;
	}
	public int getY(){
		return rect.y;
	}
	public void setWidth(int target){
		rect.width = target;
	}
	public void setHeight(int target){
		rect.height = target;
	}
	
	public void setColor(Color color){
		myColor = color;		
	}
	
	public Color getColor()
	{
		return myColor;
	}
	
	public int getWidth(){
		return rect.width;
	}
	public int getHeight(){
		return rect.height;
	}
	
	public boolean contains(int xCoord, int yCoord){
		
		if(xCoord > rect.x && xCoord < rect.x + rect.width && yCoord > rect.y && yCoord < rect.y + rect.height){
			return true;
		}
		return false;
	}
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setColor(myColor);
		g.fillRect(rect.x, rect.y, rect.width, rect.height);
		g.drawRect(rect.x, rect.y, rect.width, rect.height);
		g.setColor(Color.BLACK);
	}
	
}