import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class DShape{
	DShape[] shapes;
	Canvas can;
	
	int x;
	int y;	
	int width = 30;	
	int height = 30;
	Color myColor;
	DShapeModel myModel;
	int size = 12;
	int realY;
	String text;
	String fontName;
	Rectangle rect;

	public Rectangle returnRect()
	{
		return rect;
	}
	
	public void setX(int target) {
		
		rect.x = target;
	}
	public void setY(int target) {
		
		rect.y = target;
	}
	
	public int getX(){
		return rect.x;
	}
	public int getY(){
		return rect.y;
	}
	public void setWidth(int target){
		rect.width = target;
	}
	public void setHeight(int target){
		rect.height = target;
	}
	
	public int getWidth(){
		return rect.width;
	}
	public int getHeight(){
		return rect.height;
	}	
	//X2, Y2 methods added for lines
	public int getX2(){
		return -1;
	}
	public int getY2(){
		return -1;
	}
	public void setX2(int val){
		
	}
	public void setY2(int val){
		
	}
	public void setColor(Color color){
		myColor = color;		
	}
	
	public Color getColor()
	{
		return myColor;
	}
	public void setText(String target){
		text = target;
	}	
	public String getText()	{
		return text;
	}
	public void setFont(String target){
		fontName = target;
	}
	public String getFont(){
		return fontName;
	}
	public boolean contains(int xCoord, int yCoord){
		
		if(xCoord > x && xCoord < x + width && yCoord > y && yCoord < y + height){
			return true;
		}
		return false;
	}
	public void paintComponent(Graphics g){
		
	}



	

}