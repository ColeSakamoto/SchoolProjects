
public interface ModelListener {
	
	public void modelChanged();

}
