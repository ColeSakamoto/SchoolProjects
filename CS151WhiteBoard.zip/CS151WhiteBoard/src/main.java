
public class main {
	 public static void main(String[] args){
		 WhiteBoard as = new WhiteBoard();
		 as.theCanvas.addController(as);
	 }
}
